import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { 
  User, Shift, Product, ProductBatch, Transaction, TransactionLine, 
  MpesaLog, AuditVoid, PettyCashLog, SafeDropLog, Supplier, PurchaseOrder, 
  Customer, MpesaCredentials, ReceiptTemplate, SyncAttempt 
} from "./src/types";

const PORT = 3000;
const DB_PATH = path.join(process.cwd(), "src", "db");
const DB_FILE = path.join(DB_PATH, "mock_db.json");

// Ensure DB directory exists
if (!fs.existsSync(DB_PATH)) {
  fs.mkdirSync(DB_PATH, { recursive: true });
}

// Initial Database Template
const initialDB = {
  users: [
    { id: "u1", name: "Administrator", role: "Admin", pin_code: "1111", status: "Active", average_speed: 1.2, scan_count: 320 },
    { id: "u2", name: "Joy Cashier", role: "Seller", pin_code: "2222", status: "Active", average_speed: 1.8, scan_count: 145 },
    { id: "u3", name: "Abel Cashier", role: "Seller", pin_code: "3333", status: "Active", average_speed: 2.1, scan_count: 98 }
  ] as User[],
  shifts: [] as Shift[],
  products: [
    { id: "p1", barcode: "6100000001", sku_code: "BREAD-01", name: "Superloaf Bread 400g", buying_price: 55, selling_price: 65, wholesale_price: 60, wholesale_threshold: 6, stock_level: 45, min_stock_level: 10, category_id: "cat_bakery", category_name: "Bakery", tax_category: "A", image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=100&auto=format&fit=crop" },
    { id: "p2", barcode: "6100000002", sku_code: "MILK-02", name: "KCC Fresh Milk 500ml", buying_price: 58, selling_price: 70, wholesale_price: 66, wholesale_threshold: 12, stock_level: 8, min_stock_level: 15, category_id: "cat_dairy", category_name: "Dairy", tax_category: "A", image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?w=100&auto=format&fit=crop" },
    { id: "p3", barcode: "6100000003", sku_code: "SODA-03", name: "Coca-Cola 350ml", buying_price: 38, selling_price: 50, wholesale_price: 45, wholesale_threshold: 24, stock_level: 120, min_stock_level: 20, category_id: "cat_beverages", category_name: "Beverages", tax_category: "A", image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=100&auto=format&fit=crop" },
    { id: "p4", barcode: "6100000004", sku_code: "SUGAR-04", name: "Kabras Sugar 1kg", buying_price: 130, selling_price: 150, wholesale_price: 142, wholesale_threshold: 10, stock_level: 50, min_stock_level: 15, category_id: "cat_groceries", category_name: "Groceries", tax_category: "B", image: "https://images.unsplash.com/photo-1581441363689-1f3c3c414635?w=100&auto=format&fit=crop" },
    { id: "p5", barcode: "6100000005", sku_code: "BBAND-05", name: "Blue Band Margarine 250g", buying_price: 180, selling_price: 210, wholesale_price: 195, wholesale_threshold: 5, stock_level: 25, min_stock_level: 5, category_id: "cat_spreads", category_name: "Spreads", tax_category: "A", image: "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=100&auto=format&fit=crop" },
    { id: "p6", barcode: "6100000006", sku_code: "COIL-06", name: "Fresh Fri Cooking Oil 1L", buying_price: 275, selling_price: 310, wholesale_price: 295, wholesale_threshold: 6, stock_level: 12, min_stock_level: 8, category_id: "cat_groceries", category_name: "Groceries", tax_category: "A", image: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=100&auto=format&fit=crop" }
  ] as Product[],
  batches: [
    { id: "b1", product_id: "p1", batch_number: "SL-B01", expiry_date: "2026-07-20", quantity_received: 50, manufacturing_date: "2026-07-10" },
    { id: "b2", product_id: "p2", batch_number: "KCC-B45", expiry_date: "2026-07-25", quantity_received: 20, manufacturing_date: "2026-07-11" },
    { id: "b3", product_id: "p5", batch_number: "BB-B09", expiry_date: "2026-12-31", quantity_received: 30, manufacturing_date: "2026-06-01" }
  ] as ProductBatch[],
  transactions: [] as Transaction[],
  mpesaLogs: [] as MpesaLog[],
  auditVoids: [] as AuditVoid[],
  pettyCash: [] as PettyCashLog[],
  safeDrops: [] as SafeDropLog[],
  suppliers: [
    { id: "s1", name: "Kazi Bora Wholesalers", phone: "0722000111", email: "orders@kazibora.co.ke", address: "Warehouse A4, Industrial Area, Nairobi", balance_due: 45000 },
    { id: "s2", name: "Brookside Dairy Ltd", phone: "0711999888", email: "sales@brookside.co.ke", address: "Ruiru Bypass, Kiambu", balance_due: 15200 }
  ] as Supplier[],
  purchaseOrders: [] as PurchaseOrder[],
  customers: [
    { id: "c1", name: "Mama Kiprop", phone: "254712345678", loyalty_points: 450, credit_balance: 1200, birthday: "1985-07-12" },
    { id: "c2", name: "Babu Mwangi", phone: "254722554433", loyalty_points: 120, credit_balance: 0, birthday: "1955-11-20" },
    { id: "c3", name: "Esther Chemutai", phone: "254733998877", loyalty_points: 800, credit_balance: 5400, birthday: "1992-09-05" }
  ] as Customer[],
  settings: {
    mpesa: {
      tillNumber: "5123456",
      consumerKey: "uXyZ123DarajaConsumerKeyAwesome",
      consumerSecret: "SecretDarajaCredentialsXyz9876",
      passkey: "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919",
      callbackUrl: "https://api.myretailpos.co.ke/api/mpesa/callback",
      isEnabled: true
    } as MpesaCredentials,
    receipt: {
      logoText: "🛒 METRO SMART SUPERMARKET",
      shopName: "Metro Smart Retail Ltd",
      kraPin: "P051234567Z",
      address: "Moi Avenue, Nairobi, Kenya",
      phone: "+254 700 123 456",
      footerText: "THANK YOU FOR SHOPPING WITH US! GOODS ONCE SOLD ARE NOT RETURNABLE UNLESS DEFECTIVE."
    } as ReceiptTemplate
  },
  syncAttempts: [] as SyncAttempt[]
};

// Database utility functions
function readDB() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      return JSON.parse(data);
    } else {
      writeDB(initialDB);
      return initialDB;
    }
  } catch (err) {
    console.error("Error reading database file, using in-memory fallback", err);
    return initialDB;
  }
}

function writeDB(data: typeof initialDB) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing database file", err);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "50mb" }));

  // Initialize DB
  let db = readDB();

  // API ROUNTES
  
  // Auth Login
  app.post("/api/auth/login", (req, res) => {
    const { pin } = req.body;
    db = readDB();
    const user = db.users.find((u: User) => u.pin_code === pin && u.status === "Active");
    if (user) {
      res.json({ success: true, user });
    } else {
      res.status(401).json({ success: false, message: "Invalid Security PIN" });
    }
  });

  // Get current active shift for cashier
  app.get("/api/shifts/active/:userId", (req, res) => {
    const { userId } = req.params;
    db = readDB();
    const activeShift = db.shifts.find((s: Shift) => s.user_id === userId && !s.is_closed);
    res.json({ activeShift: activeShift || null });
  });

  // Open Shift
  app.post("/api/shifts/open", (req, res) => {
    const { userId, cashierName, openingFloat } = req.body;
    db = readDB();
    
    // Close any unclosed shifts for this user first
    db.shifts = db.shifts.map((s: Shift) => {
      if (s.user_id === userId && !s.is_closed) {
        return { ...s, is_closed: true, end_time: new Date().toISOString() };
      }
      return s;
    });

    const newShift: Shift = {
      id: "sh_" + Date.now(),
      user_id: userId,
      cashier_name: cashierName,
      start_time: new Date().toISOString(),
      end_time: null,
      opening_float: Number(openingFloat),
      closing_cash_count: null,
      expected_cash: Number(openingFloat),
      expected_mpesa: 0,
      variance_cash: null,
      variance_mpesa: null,
      is_closed: false,
      mid_day_drops: 0,
      safe_drops: 0,
      petty_cash_expenses: 0
    };

    db.shifts.push(newShift);
    writeDB(db);
    res.json({ success: true, shift: newShift });
  });

  // Safe Drop (Cash pulled mid-shift)
  app.post("/api/shifts/safe-drop", (req, res) => {
    const { shiftId, amount, cashierId, cashierName, managerId, managerName } = req.body;
    db = readDB();
    const shift = db.shifts.find((s: Shift) => s.id === shiftId);
    if (!shift) {
      return res.status(404).json({ success: false, message: "Shift not found" });
    }

    const dropAmount = Number(amount);
    const newLog: SafeDropLog = {
      id: "drop_" + Date.now(),
      amount: dropAmount,
      timestamp: new Date().toISOString(),
      cashier_id: cashierId,
      cashier_name: cashierName,
      manager_id: managerId,
      manager_name: managerName,
      shift_id: shiftId
    };

    shift.safe_drops += dropAmount;
    shift.expected_cash -= dropAmount; // Expect less cash in drawer because it went to safe

    db.safeDrops.push(newLog);
    writeDB(db);
    res.json({ success: true, shift, log: newLog });
  });

  // Petty Cash Expense from drawer
  app.post("/api/shifts/petty-cash", (req, res) => {
    const { shiftId, amount, reason, userId, cashierName } = req.body;
    db = readDB();
    const shift = db.shifts.find((s: Shift) => s.id === shiftId);
    if (!shift) {
      return res.status(440).json({ success: false, message: "Shift not found" });
    }

    const expenseAmount = Number(amount);
    const newLog: PettyCashLog = {
      id: "petty_" + Date.now(),
      amount: expenseAmount,
      reason,
      timestamp: new Date().toISOString(),
      user_id: userId,
      cashier_name: cashierName,
      shift_id: shiftId
    };

    shift.petty_cash_expenses += expenseAmount;
    shift.expected_cash -= expenseAmount; // Petty cash is paid out of the drawer, reducing expected closing cash

    db.pettyCash.push(newLog);
    writeDB(db);
    res.json({ success: true, shift, log: newLog });
  });

  // Close Shift (Reconciliation)
  app.post("/api/shifts/close", (req, res) => {
    const { shiftId, closingCashCount, closingMpesaCount } = req.body;
    db = readDB();
    const shift = db.shifts.find((s: Shift) => s.id === shiftId);
    if (!shift) {
      return res.status(404).json({ success: false, message: "Shift not found" });
    }

    const countedCash = Number(closingCashCount);
    const countedMpesa = Number(closingMpesaCount);

    shift.is_closed = true;
    shift.end_time = new Date().toISOString();
    shift.closing_cash_count = countedCash;
    shift.variance_cash = countedCash - shift.expected_cash;
    shift.variance_mpesa = countedMpesa - shift.expected_mpesa;

    writeDB(db);
    res.json({ success: true, shift });
  });

  // Get products list
  app.get("/api/products", (req, res) => {
    db = readDB();
    res.json(db.products);
  });

  // Create/Update Product
  app.post("/api/products", (req, res) => {
    const productData = req.body;
    db = readDB();
    if (productData.id) {
      // Update
      db.products = db.products.map((p: Product) => p.id === productData.id ? { ...p, ...productData } : p);
    } else {
      // Create
      const newProduct = {
        ...productData,
        id: "p_" + Date.now(),
        stock_level: Number(productData.stock_level || 0),
        min_stock_level: Number(productData.min_stock_level || 5),
        buying_price: Number(productData.buying_price || 0),
        selling_price: Number(productData.selling_price || 0),
        wholesale_price: Number(productData.wholesale_price || productData.selling_price)
      };
      db.products.push(newProduct);
    }
    writeDB(db);
    res.json({ success: true, products: db.products });
  });

  // Bulk Product CSV Upload
  app.post("/api/products/bulk-upload", (req, res) => {
    const { products: csvProducts } = req.body;
    db = readDB();
    let addedCount = 0;
    let updatedCount = 0;

    csvProducts.forEach((item: any) => {
      const existing = db.products.find((p: Product) => p.barcode === item.barcode || p.sku_code === item.sku_code);
      const parsedProduct = {
        name: item.name || "Bulk Product",
        barcode: item.barcode || Math.floor(Math.random() * 10000000000).toString(),
        sku_code: item.sku_code || "SKU-" + Math.floor(Math.random() * 100000),
        buying_price: Number(item.buying_price || 0),
        selling_price: Number(item.selling_price || 0),
        wholesale_price: Number(item.wholesale_price || item.selling_price || 0),
        wholesale_threshold: Number(item.wholesale_threshold || 10),
        stock_level: Number(item.stock_level || 0),
        min_stock_level: Number(item.min_stock_level || 5),
        category_id: item.category_id || "cat_general",
        category_name: item.category_name || "General",
        tax_category: (item.tax_category === "B" || item.tax_category === "C") ? item.tax_category : "A"
      };

      if (existing) {
        Object.assign(existing, parsedProduct);
        updatedCount++;
      } else {
        db.products.push({
          ...parsedProduct,
          id: "p_" + Math.random().toString(36).substr(2, 9)
        });
        addedCount++;
      }
    });

    writeDB(db);
    res.json({ success: true, addedCount, updatedCount, products: db.products });
  });

  // Delete product
  app.delete("/api/products/:id", (req, res) => {
    const { id } = req.params;
    db = readDB();
    db.products = db.products.filter((p: Product) => p.id !== id);
    writeDB(db);
    res.json({ success: true, products: db.products });
  });

  // Expiry Batches Log
  app.get("/api/batches", (req, res) => {
    db = readDB();
    res.json(db.batches);
  });

  app.post("/api/batches", (req, res) => {
    const batch = req.body;
    db = readDB();
    const newBatch: ProductBatch = {
      id: batch.id || "batch_" + Date.now(),
      product_id: batch.product_id,
      batch_number: batch.batch_number,
      expiry_date: batch.expiry_date,
      quantity_received: Number(batch.quantity_received),
      manufacturing_date: batch.manufacturing_date
    };

    if (batch.id) {
      db.batches = db.batches.map((b: ProductBatch) => b.id === batch.id ? newBatch : b);
    } else {
      db.batches.push(newBatch);
      // Automatically increase product stock level upon receiving batch
      const prod = db.products.find((p: Product) => p.id === batch.product_id);
      if (prod) {
        prod.stock_level += newBatch.quantity_received;
      }
    }
    writeDB(db);
    res.json({ success: true, batches: db.batches, products: db.products });
  });

  // Get Suppliers and Purchase Orders
  app.get("/api/suppliers", (req, res) => {
    db = readDB();
    res.json(db.suppliers);
  });

  app.post("/api/suppliers", (req, res) => {
    const supplier = req.body;
    db = readDB();
    if (supplier.id) {
      db.suppliers = db.suppliers.map((s: Supplier) => s.id === supplier.id ? { ...s, ...supplier } : s);
    } else {
      db.suppliers.push({
        ...supplier,
        id: "s_" + Date.now(),
        balance_due: Number(supplier.balance_due || 0)
      });
    }
    writeDB(db);
    res.json({ success: true, suppliers: db.suppliers });
  });

  // Generate Purchase Order PDF simulated
  app.get("/api/purchase-orders", (req, res) => {
    db = readDB();
    res.json(db.purchaseOrders);
  });

  app.post("/api/purchase-orders", (req, res) => {
    const po = req.body;
    db = readDB();
    const newPO: PurchaseOrder = {
      id: "PO-" + Math.floor(1000 + Math.random() * 9000),
      supplier_id: po.supplier_id,
      supplier_name: po.supplier_name,
      date: new Date().toISOString().split('T')[0],
      status: po.status || "Sent",
      items: po.items,
      total_amount: po.total_amount
    };
    db.purchaseOrders.push(newPO);
    writeDB(db);
    res.json({ success: true, purchaseOrders: db.purchaseOrders });
  });

  // Damage & Loss Logging
  app.post("/api/products/damage-loss", (req, res) => {
    const { productId, quantity, reason, userId, cashierName } = req.body;
    db = readDB();
    const product = db.products.find((p: Product) => p.id === productId);
    if (!product) return res.status(404).json({ success: false, message: "Product not found" });

    const qty = Number(quantity);
    product.stock_level = Math.max(0, product.stock_level - qty);

    // Log in Audit Trail / Audit Voids as stock damage adjustment
    const log: AuditVoid = {
      id: "void_" + Date.now(),
      timestamp: new Date().toISOString(),
      item_removed_name: `${product.name} (${qty} units written off)`,
      quantity_before: product.stock_level + qty,
      action_taken: "Price Override", // Used as category in audit trail
      user_id: userId,
      cashier_name: cashierName,
      reason: `Damage/Loss: ${reason}`
    };

    db.auditVoids.push(log);
    writeDB(db);
    res.json({ success: true, products: db.products, auditVoids: db.auditVoids });
  });

  // Customers (Loyalty, credit limits, etc.)
  app.get("/api/customers", (req, res) => {
    db = readDB();
    res.json(db.customers);
  });

  app.post("/api/customers", (req, res) => {
    const customer = req.body;
    db = readDB();
    if (customer.id) {
      db.customers = db.customers.map((c: Customer) => c.id === customer.id ? { ...c, ...customer } : c);
    } else {
      db.customers.push({
        ...customer,
        id: "c_" + Date.now(),
        loyalty_points: Number(customer.loyalty_points || 0),
        credit_balance: Number(customer.credit_balance || 0)
      });
    }
    writeDB(db);
    res.json({ success: true, customers: db.customers });
  });

  // Get settings
  app.get("/api/settings", (req, res) => {
    db = readDB();
    res.json({ settings: db.settings });
  });

  app.post("/api/settings", (req, res) => {
    const { mpesa, receipt, googleSpreadsheetId, googleSpreadsheetUrl } = req.body;
    db = readDB();
    if (mpesa) db.settings.mpesa = { ...db.settings.mpesa, ...mpesa };
    if (receipt) db.settings.receipt = { ...db.settings.receipt, ...receipt };
    if (googleSpreadsheetId !== undefined) db.settings.googleSpreadsheetId = googleSpreadsheetId;
    if (googleSpreadsheetUrl !== undefined) db.settings.googleSpreadsheetUrl = googleSpreadsheetUrl;
    writeDB(db);
    res.json({ success: true, settings: db.settings });
  });

  // User/Seller Management endpoints
  app.get("/api/users", (req, res) => {
    db = readDB();
    res.json(db.users);
  });

  app.post("/api/users", (req, res) => {
    const userData = req.body;
    db = readDB();
    if (userData.id) {
      db.users = db.users.map((u: User) => u.id === userData.id ? { ...u, ...userData } : u);
    } else {
      const newUser = {
        ...userData,
        id: "u_" + Date.now(),
        role: userData.role || "Seller",
        status: userData.status || "Active",
        pin_code: userData.pin_code || "0000",
        average_speed: 1.5,
        scan_count: 0
      };
      db.users.push(newUser);
    }
    writeDB(db);
    res.json({ success: true, users: db.users });
  });

  app.delete("/api/users/:id", (req, res) => {
    const { id } = req.params;
    db = readDB();
    db.users = db.users.filter((u: User) => u.id !== id);
    writeDB(db);
    res.json({ success: true, users: db.users });
  });

  // M-Pesa Transaction Logs endpoint
  app.get("/api/mpesa/logs", (req, res) => {
    db = readDB();
    res.json(db.mpesaLogs || []);
  });

  // Get Audit Trail / Voids
  app.get("/api/audit-voids", (req, res) => {
    db = readDB();
    res.json(db.auditVoids);
  });

  // Log a manual Cashier void (cart deletion or cart wipe)
  app.post("/api/audit-voids", (req, res) => {
    const { item_removed_name, quantity_before, action_taken, user_id, cashier_name, reason } = req.body;
    db = readDB();
    const newLog: AuditVoid = {
      id: "void_" + Date.now(),
      timestamp: new Date().toISOString(),
      item_removed_name,
      quantity_before: Number(quantity_before),
      action_taken,
      user_id,
      cashier_name,
      reason
    };
    db.auditVoids.push(newLog);
    writeDB(db);
    res.json({ success: true, auditVoids: db.auditVoids });
  });

  // Create Transaction (Normal Checkout)
  app.post("/api/transactions", (req, res) => {
    const { transaction } = req.body;
    db = readDB();

    // Verify cashier constraints or manage overrides if any
    const newTx: Transaction = {
      ...transaction,
      id: transaction.id || "tx_" + Date.now(),
      timestamp: transaction.timestamp || new Date().toISOString(),
      receipt_number: transaction.receipt_number || "RCPT-" + Math.floor(100000 + Math.random() * 900000),
      is_synced: true,
      sync_attempts: 1,
      kra_qr_code: transaction.kra_qr_code || `https://etims.kra.go.ke/query/invoice?pin=${db.settings.receipt.kraPin}&num=${transaction.receipt_number}&sig=KRA_${Math.random().toString(36).substr(2,12).toUpperCase()}`,
      e_tims_signature: transaction.e_tims_signature || `ETIMS-SIG-${Math.random().toString(36).substr(2,16).toUpperCase()}`
    };

    // Process Stock deductions
    newTx.lines.forEach((line: TransactionLine) => {
      const prod = db.products.find((p: Product) => p.id === line.product_id);
      if (prod) {
        // If parent-child link exists
        if (prod.parent_id && prod.child_ratio) {
          const parent = db.products.find((p: Product) => p.id === prod.parent_id);
          if (parent) {
            // Deduct fractional stock from wholesale parent
            parent.stock_level = Math.max(0, parent.stock_level - (line.quantity / prod.child_ratio));
          }
        } else {
          prod.stock_level = Math.max(0, prod.stock_level - line.quantity);
        }
      }
    });

    // Update active Shift totals
    const shift = db.shifts.find((s: Shift) => s.id === newTx.shift_id);
    if (shift) {
      if (newTx.payment_method === "Cash") {
        shift.expected_cash += newTx.grand_total;
      } else if (newTx.payment_method === "M-Pesa") {
        shift.expected_mpesa += newTx.grand_total;
      } else if (newTx.payment_method === "Split") {
        shift.expected_cash += newTx.cash_paid;
        shift.expected_mpesa += newTx.mpesa_paid;
      }
    }

    // Process Loyalty points & credit balances
    if (newTx.buyer_kra_pin) {
      // B2B KRA PIN logic
    }
    // Check if there's a matching customer by phone
    // Assuming matching customer is passed or we scan phone
    const mpesaCodeUsed = newTx.mpesa_code;
    
    db.transactions.push(newTx);
    writeDB(db);
    res.json({ success: true, transaction: newTx, products: db.products });
  });

  // Offline Transactions Sync Engine
  app.post("/api/transactions/sync", (req, res) => {
    const { batch } = req.body; // Array of offline Transactions
    db = readDB();
    const results: { id: string; success: boolean; error?: string }[] = [];
    let addedCount = 0;

    batch.forEach((tx: any) => {
      // Check for duplicate receipt number to prevent double logging
      const exists = db.transactions.find((t: Transaction) => t.receipt_number === tx.receipt_number || t.id === tx.id);
      if (exists) {
        results.push({ id: tx.id, success: true }); // Already processed previously
        return;
      }

      try {
        const processedTx: Transaction = {
          ...tx,
          is_synced: true,
          sync_attempts: (tx.sync_attempts || 0) + 1,
          kra_qr_code: tx.kra_qr_code || `https://etims.kra.go.ke/query/invoice?pin=${db.settings.receipt.kraPin}&num=${tx.receipt_number}&sig=KRA_SYNC_${Math.random().toString(36).substr(2,10).toUpperCase()}`,
          e_tims_signature: tx.e_tims_signature || `ETIMS-SIG-SYNC-${Math.random().toString(36).substr(2,12).toUpperCase()}`
        };

        // Deduct products stock
        processedTx.lines.forEach((line: TransactionLine) => {
          const prod = db.products.find((p: Product) => p.id === line.product_id);
          if (prod) {
            prod.stock_level = Math.max(0, prod.stock_level - line.quantity);
          }
        });

        // Update active Shift totals (if shift exists and not closed)
        const shift = db.shifts.find((s: Shift) => s.id === processedTx.shift_id);
        if (shift && !shift.is_closed) {
          if (processedTx.payment_method === "Cash") {
            shift.expected_cash += processedTx.grand_total;
          } else if (processedTx.payment_method === "M-Pesa") {
            shift.expected_mpesa += processedTx.grand_total;
          } else if (processedTx.payment_method === "Split") {
            shift.expected_cash += processedTx.cash_paid;
            shift.expected_mpesa += processedTx.mpesa_paid;
          }
        }

        db.transactions.push(processedTx);
        addedCount++;
        results.push({ id: tx.id, success: true });
      } catch (err: any) {
        results.push({ id: tx.id, success: false, error: err.message });
      }
    });

    // Record the Sync Attempt log
    const attempt: SyncAttempt = {
      id: "sync_" + Date.now(),
      timestamp: new Date().toISOString(),
      batch_size: batch.length,
      success: results.every(r => r.success)
    };
    db.syncAttempts.push(attempt);

    writeDB(db);
    res.json({ success: true, results, addedCount, products: db.products, syncAttempts: db.syncAttempts });
  });

  // Get Sync attempts logs
  app.get("/api/sync-attempts", (req, res) => {
    db = readDB();
    res.json(db.syncAttempts);
  });

  // Fetch transactions list
  app.get("/api/transactions", (req, res) => {
    db = readDB();
    res.json(db.transactions);
  });

  // SAFARICOM M-PESA DARAJA API SIMULATION MODULE
  // 1. Trigger STK Push
  app.post("/api/mpesa/stk-push", (req, res) => {
    const { phone, amount, txId } = req.body;
    db = readDB();
    
    const checkoutRequestId = "ws_CO_" + Math.floor(Math.random() * 1000000000);
    const merchantRequestId = "req_" + Math.floor(Math.random() * 10000000);

    const newLog: MpesaLog = {
      id: "mp_" + Date.now(),
      checkout_request_id: checkoutRequestId,
      merchant_request_id: merchantRequestId,
      mpesa_code: null,
      status: "Pending",
      tx_id: txId || null,
      phone,
      amount: Number(amount),
      timestamp: new Date().toISOString()
    };

    db.mpesaLogs.push(newLog);
    writeDB(db);

    // Run asynchronous simulation of Daraja callback response
    setTimeout(() => {
      // Simulate user actions after some time
      const latestDB = readDB();
      const currentLog = latestDB.mpesaLogs.find((l: MpesaLog) => l.checkout_request_id === checkoutRequestId);
      if (currentLog && currentLog.status === "Pending") {
        // 80% Success rate for normal simulations, others fail/timeout
        const randomOutcome = Math.random();
        if (randomOutcome < 0.85) {
          currentLog.status = "Success";
          currentLog.mpesa_code = "QG" + Math.random().toString(36).substring(2, 10).toUpperCase();
        } else if (randomOutcome < 0.93) {
          currentLog.status = "Cancelled";
          currentLog.error_message = "User cancelled PIN prompt/entered wrong PIN";
        } else {
          currentLog.status = "Failed";
          currentLog.error_message = "Insufficient funds in subscriber's M-Pesa wallet";
        }
        writeDB(latestDB);
        console.log(`[M-Pesa Webhook Callback Processed] ID: ${checkoutRequestId}, Status: ${currentLog.status}`);
      }
    }, 6000); // 6 seconds wait to mimic real-world PIN typing on phone!

    res.json({ 
      success: true, 
      checkoutRequestId, 
      merchantRequestId, 
      status: "Pending",
      message: "Daraja API STK Push initiated successfully" 
    });
  });

  // 2. Poll STK Push status
  app.get("/api/mpesa/status/:checkoutRequestId", (req, res) => {
    const { checkoutRequestId } = req.params;
    db = readDB();
    const log = db.mpesaLogs.find((l: MpesaLog) => l.checkout_request_id === checkoutRequestId);
    if (!log) {
      res.status(404).json({ success: false, message: "M-Pesa log not found" });
    } else {
      res.json({ success: true, status: log.status, mpesa_code: log.mpesa_code, error_message: log.error_message });
    }
  });

  // Manual M-Pesa verification and reconciliation auto-matcher
  app.post("/api/mpesa/manual-verify", (req, res) => {
    const { mpesaCode, txId } = req.body;
    db = readDB();
    
    // Check if code is already used in active transaction to prevent duplication
    const duplicate = db.transactions.find((t: Transaction) => t.mpesa_code === mpesaCode);
    if (duplicate) {
      return res.status(400).json({ success: false, message: "M-Pesa code already linked to another transaction" });
    }

    // Match code against a "master Safaricom bank settlement" simulation (mocking Daraja incoming API logs)
    const mockDarajaCodeIsValid = mpesaCode.length >= 8; // Simulated check
    if (mockDarajaCodeIsValid) {
      const tx = db.transactions.find((t: Transaction) => t.id === txId);
      if (tx) {
        tx.mpesa_code = mpesaCode;
        writeDB(db);
        return res.json({ success: true, message: "M-Pesa code reconciled successfully!", transaction: tx });
      }
    }
    res.status(400).json({ success: false, message: "Invalid M-Pesa Reference Code format" });
  });

  // WhatsApp Simulated API Notifications & Reminders
  app.post("/api/whatsapp/send-receipt", (req, res) => {
    const { phone, receiptNumber, text } = req.body;
    console.log(`[Simulated WhatsApp API] Sending Digital Receipt ${receiptNumber} to +${phone}. Text: ${text}`);
    res.json({ success: true, message: `Digital receipt sent to WhatsApp +${phone} successfully.` });
  });

  app.post("/api/whatsapp/send-debt-reminder", (req, res) => {
    const { phone, name, balanceDue } = req.body;
    db = readDB();
    const mpesa = db.settings.mpesa;
    const message = `Dear ${name}, this is a gentle reminder from Metro Smart Retail. Your current outstanding store credit is KSh ${balanceDue}. Please clear your balance via Lipa Na M-Pesa Buy Goods Till Number ${mpesa.tillNumber}. Thank you for your continued loyalty!`;
    
    console.log(`[Simulated WhatsApp API] Debt Reminder to +${phone}: ${message}`);
    res.json({ success: true, message: `Debt reminder sent to +${phone} successfully!`, simulatedText: message });
  });

  // VITE SETUP FOR FULL STACK ENTRY
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
