import { Transaction, Product, SyncAttempt } from "../types";

// Simulated network state helper
let isOnlineCached = true;

export const checkNetworkStatus = async (): Promise<boolean> => {
  try {
    const res = await fetch("/api/health", { method: "HEAD", cache: "no-store" });
    isOnlineCached = res.ok;
    return res.ok;
  } catch {
    isOnlineCached = false;
    return false;
  }
};

export const getCachedNetworkStatus = (): boolean => {
  return isOnlineCached;
};

// Local storage keys
const OFFLINE_TX_KEY = "pos_offline_transactions";
const LOCAL_PRODUCTS_KEY = "pos_local_products";
const SYNC_LOGS_KEY = "pos_sync_logs";

export const offlineStore = {
  // Get queued offline transactions
  getQueuedTransactions(): Transaction[] {
    try {
      const data = localStorage.getItem(OFFLINE_TX_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  // Save transaction to offline queue
  saveTransactionOffline(tx: Transaction): void {
    const queue = this.getQueuedTransactions();
    // Prevent duplicate
    if (!queue.some(t => t.id === tx.id)) {
      queue.push({
        ...tx,
        is_synced: false,
        sync_attempts: 1,
        timestamp: new Date().toISOString()
      });
      localStorage.setItem(OFFLINE_TX_KEY, JSON.stringify(queue));
    }

    // Also deduct stock locally immediately
    const products = this.getLocalProducts();
    if (products.length > 0) {
      tx.lines.forEach(line => {
        const prod = products.find(p => p.id === line.product_id);
        if (prod) {
          prod.stock_level = Math.max(0, prod.stock_level - line.quantity);
        }
      });
      this.saveProductsLocal(products);
    }
  },

  // Clear synced transactions from queue
  removeTransactionsFromQueue(ids: string[]): void {
    const queue = this.getQueuedTransactions();
    const updated = queue.filter(tx => !ids.includes(tx.id));
    localStorage.setItem(OFFLINE_TX_KEY, JSON.stringify(updated));
  },

  // Store/Get local products backup for offline lookups
  getLocalProducts(): Product[] {
    try {
      const data = localStorage.getItem(LOCAL_PRODUCTS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveProductsLocal(products: Product[]): void {
    localStorage.setItem(LOCAL_PRODUCTS_KEY, JSON.stringify(products));
  },

  // Get Sync attempts logs
  getSyncLogs(): SyncAttempt[] {
    try {
      const data = localStorage.getItem(SYNC_LOGS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addSyncLog(log: Omit<SyncAttempt, "id" | "timestamp">): void {
    const logs = this.getSyncLogs();
    const newLog: SyncAttempt = {
      ...log,
      id: "log_" + Date.now(),
      timestamp: new Date().toISOString()
    };
    logs.unshift(newLog); // latest first
    localStorage.setItem(SYNC_LOGS_KEY, JSON.stringify(logs.slice(0, 50))); // keep last 50 logs
  }
};
