import { Product, Transaction } from "../types";

export interface SpreadsheetInfo {
  spreadsheetId: string;
  spreadsheetUrl: string;
}

/**
 * Creates a new Google Spreadsheet "Metro Smart Retail Ledger" with three sheets:
 * 1. Products Catalog
 * 2. Transactions Ledger
 * 3. M-Pesa Payments
 */
export async function createSpreadsheet(accessToken: string): Promise<SpreadsheetInfo> {
  const response = await fetch("https://sheets.googleapis.com/v4/spreadsheets", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      properties: {
        title: "Metro Smart Retail Ledger",
      },
      sheets: [
        {
          properties: {
            title: "Products Catalog",
          },
        },
        {
          properties: {
            title: "Transactions Ledger",
          },
        },
        {
          properties: {
            title: "M-Pesa Payments",
          },
        },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Failed to create spreadsheet: ${errText}`);
  }

  const data = await response.json();
  const spreadsheetId = data.spreadsheetId;
  const spreadsheetUrl = data.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  // Initialize headers for each sheet
  await initializeSheetHeaders(accessToken, spreadsheetId);

  return { spreadsheetId, spreadsheetUrl };
}

/**
 * Initializes the headers for the sheets
 */
async function initializeSheetHeaders(accessToken: string, spreadsheetId: string): Promise<void> {
  const headers = {
    "Products Catalog": [
      ["Product ID", "Name", "Barcode", "SKU", "Buying Price (COGS)", "Selling Price", "Wholesale Price", "Stock Level", "Min Stock Warning", "Category"]
    ],
    "Transactions Ledger": [
      ["Timestamp", "Receipt No", "Cashier", "Payment Method", "Grand Total (KSh)", "Subtotal (KSh)", "Tax (KSh)", "M-Pesa Code", "B2B KRA PIN", "Items Purchased"]
    ],
    "M-Pesa Payments": [
      ["Timestamp", "M-Pesa Code", "Phone Number", "Amount (KSh)", "Status", "Checkout Request ID", "Error Message"]
    ]
  };

  for (const [sheetName, rows] of Object.entries(headers)) {
    await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/'${sheetName}'!A1:J1?valueInputOption=USER_ENTERED`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          range: `'${sheetName}'!A1:J1`,
          majorDimension: "ROWS",
          values: rows,
        }),
      }
    );
  }
}

/**
 * Synchronizes all products by completely overwriting the "Products Catalog" sheet
 */
export async function syncAllProductsToSheet(
  accessToken: string,
  spreadsheetId: string,
  products: Product[]
): Promise<void> {
  const sheetName = "Products Catalog";
  
  // Header row
  const rows: any[][] = [
    ["Product ID", "Name", "Barcode", "SKU", "Buying Price (COGS)", "Selling Price", "Wholesale Price", "Stock Level", "Min Stock Warning", "Category"]
  ];

  // Map products to spreadsheet rows
  products.forEach(p => {
    rows.push([
      p.id,
      p.name,
      p.barcode,
      p.sku_code,
      p.buying_price,
      p.selling_price,
      p.wholesale_price,
      p.stock_level,
      p.min_stock_level,
      p.category_name
    ]);
  });

  // To update cleanly, we clear first or just overwrite. Overwriting A1:J1000 is very simple
  const range = `'${sheetName}'!A1:J${Math.max(1000, rows.length + 50)}`;
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}?valueInputOption=USER_ENTERED`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        range,
        majorDimension: "ROWS",
        values: rows,
      }),
    }
  );

  if (!response.ok) {
    console.error("Failed to sync products to Google Sheet:", await response.text());
  }
}

/**
 * Appends a completed transaction to the "Transactions Ledger" sheet
 */
export async function appendTransactionToSheet(
  accessToken: string,
  spreadsheetId: string,
  tx: Transaction
): Promise<void> {
  const sheetName = "Transactions Ledger";
  const itemsText = tx.lines.map(l => `${l.product_name} (x${l.quantity})`).join(", ");

  const row = [
    new Date(tx.timestamp).toLocaleString(),
    tx.receipt_number || tx.id,
    tx.cashier_name,
    tx.payment_method,
    tx.grand_total,
    tx.subtotal,
    tx.tax_amount,
    tx.mpesa_code || "",
    tx.buyer_kra_pin || "",
    itemsText
  ];

  const range = `'${sheetName}'!A:J`;
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        range,
        majorDimension: "ROWS",
        values: [row],
      }),
    }
  );

  if (!response.ok) {
    console.error("Failed to append transaction to Google Sheet:", await response.text());
  }
}

/**
 * Appends an M-Pesa payment log entry to the "M-Pesa Payments" sheet
 */
export async function appendMpesaPaymentToSheet(
  accessToken: string,
  spreadsheetId: string,
  payment: {
    timestamp: string;
    mpesa_code: string | null;
    phone: string;
    amount: number;
    status: string;
    checkout_request_id: string;
    error_message?: string;
  }
): Promise<void> {
  const sheetName = "M-Pesa Payments";

  const row = [
    new Date(payment.timestamp).toLocaleString(),
    payment.mpesa_code || "PENDING",
    payment.phone,
    payment.amount,
    payment.status,
    payment.checkout_request_id,
    payment.error_message || ""
  ];

  const range = `'${sheetName}'!A:G`;
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        range,
        majorDimension: "ROWS",
        values: [row],
      }),
    }
  );

  if (!response.ok) {
    console.error("Failed to append M-Pesa payment to Google Sheet:", await response.text());
  }
}
