import React, { useState, useEffect } from "react";
import { User, Shift, Product, Transaction, AuditVoid, PettyCashLog, SafeDropLog, Supplier, PurchaseOrder, Customer } from "./types";
import SellerDashboard from "./components/SellerDashboard";
import AdminDashboard from "./components/AdminDashboard";
import { offlineStore, checkNetworkStatus } from "./utils/offlineStore";
import { Shield, Loader2, RefreshCw, KeyRound, Check, AlertCircle } from "lucide-react";

export default function App() {
  // Global Session States
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeShift, setActiveShift] = useState<Shift | null>(null);
  const [pinInput, setPinInput] = useState("");
  const [loginError, setLoginError] = useState("");
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState<"admin" | "seller">("seller");

  // System Master Entities
  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [auditVoids, setAuditVoids] = useState<AuditVoid[]>([]);
  const [pettyCash, setPettyCash] = useState<PettyCashLog[]>([]);
  const [safeDrops, setSafeDrops] = useState<SafeDropLog[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);

  // Initial Data bootstrap
  useEffect(() => {
    bootstrapSystemData();
  }, []);

  const bootstrapSystemData = async () => {
    setIsLoading(true);
    const online = await checkNetworkStatus();

    if (online) {
      try {
        await Promise.all([
          fetchProducts(),
          fetchTransactions(),
          fetchShifts(),
          fetchAuditVoids(),
          fetchSuppliers(),
          fetchPO(),
          fetchCustomers()
        ]);
      } catch (err) {
        console.error("Error bootstrapping system data, falling back to local files", err);
        loadLocalOfflineBackups();
      }
    } else {
      loadLocalOfflineBackups();
    }
    setIsLoading(false);
  };

  const loadLocalOfflineBackups = () => {
    const backupProds = offlineStore.getLocalProducts();
    if (backupProds.length > 0) {
      setProducts(backupProds);
    }
  };

  // Fetch functions linked to Express endpoints
  const fetchProducts = async () => {
    const r = await fetch("/api/products");
    const prods = await r.json();
    setProducts(prods);
    offlineStore.saveProductsLocal(prods); // Update local cache backup

    // Auto-sync products catalog to Google Sheets if configured & authorized
    import("./utils/googleAuth").then(({ getAccessToken }) => {
      const token = getAccessToken();
      if (token) {
        fetch("/api/settings")
          .then(res => res.json())
          .then(data => {
            const spreadsheetId = data.settings?.googleSpreadsheetId;
            if (spreadsheetId) {
              import("./utils/googleSheetsSync").then(({ syncAllProductsToSheet }) => {
                syncAllProductsToSheet(token, spreadsheetId, prods).catch(console.error);
              });
            }
          })
          .catch(console.error);
      }
    });
  };

  const fetchTransactions = async () => {
    const r = await fetch("/api/transactions");
    const txs = await r.json();
    setTransactions(txs);
  };

  const fetchShifts = async () => {
    // Shifts history is fetched for admin logs
    try {
      const r = await fetch("/api/shifts/history");
      const data = await r.json();
      setShifts(data || []);
    } catch {
      setShifts([]);
    }
  };

  const fetchAuditVoids = async () => {
    const r = await fetch("/api/audit-voids");
    const data = await r.json();
    setAuditVoids(data);
  };

  const fetchSuppliers = async () => {
    const r = await fetch("/api/suppliers");
    const data = await r.json();
    setSuppliers(data);
  };

  const fetchPO = async () => {
    const r = await fetch("/api/purchase-orders");
    const data = await r.json();
    setPurchaseOrders(data);
  };

  const fetchCustomers = async () => {
    const r = await fetch("/api/customers");
    const data = await r.json();
    setCustomers(data);
  };

  // Active shift checker
  const checkActiveShift = async (userId: string) => {
    try {
      const res = await fetch(`/api/shifts/active/${userId}`);
      const data = await res.json();
      if (data.activeShift) {
        setActiveShift(data.activeShift);
      } else {
        setActiveShift(null);
      }
    } catch {
      setActiveShift(null);
    }
  };

  // Login handler
  const handlePINSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pinInput.length < 4) return;

    setIsLoggingIn(true);
    setLoginError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin: pinInput })
      });
      const data = await res.json();

      if (data.success) {
        const user: User = data.user;
        setCurrentUser(user);
        setViewMode(user.role === "Admin" ? "admin" : "seller");
        await checkActiveShift(user.id);
        setPinInput("");
      } else {
        setLoginError(data.message || "Incorrect 4-digit Security PIN");
        setPinInput("");
      }
    } catch {
      // Offline fallback login for quick sandbox checks
      if (pinInput === "1111") {
        const mockAdmin: User = { id: "u1", name: "Offline Admin", role: "Admin", pin_code: "1111", status: "Active" };
        setCurrentUser(mockAdmin);
        setViewMode("admin");
      } else if (pinInput === "2222") {
        const mockJoy: User = { id: "u2", name: "Joy Cashier (Offline)", role: "Seller", pin_code: "2222", status: "Active" };
        setCurrentUser(mockJoy);
        setViewMode("seller");
      } else {
        setLoginError("Offline Mode: Incorrect Security PIN");
      }
      setPinInput("");
    }
    setIsLoggingIn(false);
  };

  // Numeric keypad inputs for POS login
  const handleKeypadPress = (val: string) => {
    if (pinInput.length < 4) {
      const newVal = pinInput + val;
      setPinInput(newVal);
      if (newVal.length === 4) {
        // Auto trigger submit on fourth digit
        setTimeout(() => {
          // Trigger form submission
          handlePINSubmit();
        }, 300);
      }
    }
  };

  const handleBackspace = () => {
    setPinInput(prev => prev.slice(0, -1));
  };

  // Cash drawer Shift interactions
  const handleOpenShift = async (float: number) => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/shifts/open", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          cashierName: currentUser.name,
          openingFloat: float
        })
      });
      const data = await res.json();
      if (data.success) {
        setActiveShift(data.shift);
      }
    } catch {
      // Offline fallback shift activator
      const offlineShift: Shift = {
        id: "sh_off_" + Date.now(),
        user_id: currentUser.id,
        cashier_name: currentUser.name,
        start_time: new Date().toISOString(),
        end_time: null,
        opening_float: float,
        closing_cash_count: null,
        expected_cash: float,
        expected_mpesa: 0,
        variance_cash: null,
        variance_mpesa: null,
        is_closed: false,
        mid_day_drops: 0,
        safe_drops: 0,
        petty_cash_expenses: 0
      };
      setActiveShift(offlineShift);
    }
  };

  const handleCloseShift = async (cashCount: number, mpesaCount: number) => {
    if (!activeShift) return;
    try {
      const res = await fetch("/api/shifts/close", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          shiftId: activeShift.id,
          closingCashCount: cashCount,
          closingMpesaCount: mpesaCount
        })
      });
      const data = await res.json();
      if (data.success) {
        alert("Shift closed successfully and discrepancy matrix filed with Admin!");
        handleLogout();
      }
    } catch {
      alert("Shift recorded locally and closed successfully!");
      handleLogout();
    }
  };

  const handleRecordVoid = async (voidLog: Omit<AuditVoid, "id" | "timestamp">) => {
    try {
      const res = await fetch("/api/audit-voids", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(voidLog)
      });
      const data = await res.json();
      if (data.success) {
        setAuditVoids(data.auditVoids);
      }
    } catch {
      // Offline fallback voids log
      const log: AuditVoid = {
        ...voidLog,
        id: "v_" + Date.now(),
        timestamp: new Date().toISOString()
      };
      setAuditVoids(prev => [log, ...prev]);
    }
  };

  const handleAddTransactionLocally = (tx: Transaction) => {
    setTransactions(prev => [tx, ...prev]);
    // Deduct stock levels in current local state immediately
    const updatedProducts: Product[] = [];
    setProducts(prev => {
      const updated = prev.map(prod => {
        const line = tx.lines.find(l => l.product_id === prod.id);
        if (line) {
          return {
            ...prod,
            stock_level: Math.max(0, prod.stock_level - line.quantity)
          };
        }
        return prod;
      });
      updatedProducts.push(...updated);
      return updated;
    });

    // Auto sync transaction to Google Sheets if configured & authorized
    import("./utils/googleAuth").then(({ getAccessToken }) => {
      const token = getAccessToken();
      if (token) {
        fetch("/api/settings")
          .then(res => res.json())
          .then(data => {
            const spreadsheetId = data.settings?.googleSpreadsheetId;
            if (spreadsheetId) {
              import("./utils/googleSheetsSync").then(({ appendTransactionToSheet, syncAllProductsToSheet }) => {
                appendTransactionToSheet(token, spreadsheetId, tx).catch(console.error);
                if (updatedProducts.length > 0) {
                  syncAllProductsToSheet(token, spreadsheetId, updatedProducts).catch(console.error);
                }
              });
            }
          })
          .catch(console.error);
      }
    });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveShift(null);
    setPinInput("");
    setLoginError("");
  };

  if (isLoading) {
    return (
      <div className="h-screen bg-slate-950 flex flex-col items-center justify-center text-white gap-4">
        <Loader2 className="w-12 h-12 text-orange-500 animate-spin" />
        <div className="font-bold tracking-widest text-xs uppercase font-mono">Booting Smart POS Node...</div>
        <div className="text-[10px] text-slate-500 font-mono">Loading core product catalogs & API gateways</div>
      </div>
    );
  }

  // LOCKED STATE: Keypad PIN access gate
  if (!currentUser) {
    return (
      <div className="h-screen bg-slate-950 text-white flex items-center justify-center p-4 overflow-hidden relative">
        {/* Subtle background ambient blur spots */}
        <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-orange-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl"></div>

        <div className="max-w-xs w-full bg-slate-900 border border-slate-700 rounded-xl p-6 shadow-2xl relative z-10 space-y-5">
          <div className="text-center space-y-1.5">
            <div className="w-12 h-12 bg-orange-500/10 text-orange-500 rounded-xl flex items-center justify-center mx-auto shadow-sm">
              <Shield className="w-6 h-6" />
            </div>
            <h1 className="text-md font-black tracking-wider uppercase font-mono">METRO REGISTER CO.</h1>
            <p className="text-[10px] text-slate-500 font-mono">SECURE LIVE ENTRY DOOR</p>
          </div>

          {/* Glassmorphic display PIN entering dots */}
          <div className="space-y-1.5">
            <div className="bg-slate-950/80 border border-slate-700 rounded-xl py-3 flex items-center justify-center gap-3 relative">
              <KeyRound className="absolute left-4 w-4 h-4 text-slate-600" />
              {[0, 1, 2, 3].map((idx) => (
                <div
                  key={idx}
                  className={`w-3.5 h-3.5 rounded-full border border-slate-600 transition-all ${
                    pinInput.length > idx 
                      ? "bg-orange-500 border-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.6)]" 
                      : "bg-transparent"
                  }`}
                />
              ))}
            </div>
            <div className="h-4">
              {loginError && (
                <div className="text-[10px] text-rose-400 font-bold flex items-center justify-center gap-1.5 animate-pulse">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{loginError}</span>
                </div>
              )}
            </div>
          </div>

          {/* Secure 10-key numeric layout matrix */}
          <div className="grid grid-cols-3 gap-2">
            {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((num) => (
              <button
                key={num}
                onClick={() => handleKeypadPress(num)}
                className="py-3 bg-slate-800/40 hover:bg-slate-800 border border-slate-700 rounded-xl text-lg font-bold font-mono transition active:scale-95"
              >
                {num}
              </button>
            ))}
            <button
              onClick={handleBackspace}
              className="py-3 bg-slate-800/20 hover:bg-slate-800/40 border border-slate-700 rounded-xl text-[10px] font-bold transition uppercase font-mono"
            >
              Clear
            </button>
            <button
              onClick={() => handleKeypadPress("0")}
              className="py-3 bg-slate-800/40 hover:bg-slate-800 border border-slate-700 rounded-xl text-lg font-bold font-mono transition active:scale-95"
            >
              0
            </button>
            <button
              onClick={() => handlePINSubmit()}
              disabled={pinInput.length < 4 || isLoggingIn}
              className="py-3 bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-white rounded-xl text-[10px] font-black transition uppercase flex items-center justify-center"
            >
              {isLoggingIn ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-5 h-5 font-bold" />}
            </button>
          </div>

          {/* Hint details for user testing convenience */}
          <div className="pt-1.5 text-center text-[9px] text-slate-500 leading-relaxed font-mono">
            Demo entry PIN codes:<br/>
            Admin PIN: <span className="text-orange-400 font-bold">1111</span> • Cashier PIN: <span className="text-orange-400 font-bold">2222</span>
          </div>
        </div>
      </div>
    );
  }

  // ACTIVE LOGGED-IN VIEW MODULES
  return (
    <div className="h-screen bg-slate-950 flex flex-col overflow-hidden">
      {/* Admin Multi-view Top Switching banner */}
      {currentUser.role === "Admin" && (
        <div className="bg-slate-900 border-b border-slate-700 px-6 py-2 flex justify-between items-center text-xs text-slate-300 relative z-40">
          <div className="flex items-center gap-1.5 font-bold text-orange-400 font-mono text-[10px]">
            <Shield className="w-4 h-4 text-orange-400" />
            <span>ADMIN SUPERUSER MULTI-VIEW ACCESS CONTROL ENABLED</span>
          </div>
          <div className="flex bg-slate-950 p-1 rounded-md border border-slate-700">
            <button
              onClick={() => setViewMode("admin")}
              className={`px-3 py-1 font-bold rounded text-[11px] transition ${viewMode === "admin" ? "bg-slate-700 text-white shadow-sm border border-slate-600" : "text-slate-400 hover:text-slate-200"}`}
            >
              Control Room (Admin Panel)
            </button>
            <button
              onClick={() => setViewMode("seller")}
              className={`px-3 py-1 font-bold rounded text-[11px] transition ${viewMode === "seller" ? "bg-slate-700 text-white shadow-sm border border-slate-600" : "text-slate-400 hover:text-slate-200"}`}
            >
              Seller Checkout Register
            </button>
          </div>
        </div>
      )}

      {/* Render selected workspace */}
      {viewMode === "admin" && currentUser.role === "Admin" ? (
        <AdminDashboard
          currentUser={currentUser}
          onLogout={handleLogout}
          products={products}
          onRefreshProducts={fetchProducts}
          transactions={transactions}
          onRefreshTransactions={fetchTransactions}
          shifts={shifts}
          auditVoids={auditVoids}
          onRefreshAuditVoids={fetchAuditVoids}
          pettyCash={pettyCash}
          safeDrops={safeDrops}
          suppliers={suppliers}
          onRefreshSuppliers={fetchSuppliers}
          purchaseOrders={purchaseOrders}
          onRefreshPO={fetchPO}
          customers={customers}
          onRefreshCustomers={fetchCustomers}
        />
      ) : (
        <SellerDashboard
          currentUser={currentUser}
          onLogout={handleLogout}
          activeShift={activeShift}
          onOpenShift={handleOpenShift}
          onCloseShift={handleCloseShift}
          products={products}
          onRefreshProducts={fetchProducts}
          onRecordVoid={handleRecordVoid}
          onAddTransaction={handleAddTransactionLocally}
        />
      )}
    </div>
  );
}
