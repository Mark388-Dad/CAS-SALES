export type UserRole = "Admin" | "Seller";

export interface User {
  id: string;
  name: string;
  role: UserRole;
  pin_code: string; // 4-digit code
  status: "Active" | "Inactive";
  average_speed?: number; // seconds per item
  scan_count?: number;
}

export interface Shift {
  id: string;
  user_id: string;
  cashier_name: string;
  start_time: string;
  end_time: string | null;
  opening_float: number;
  closing_cash_count: number | null;
  expected_cash: number;
  expected_mpesa: number;
  variance_cash: number | null;
  variance_mpesa: number | null;
  is_closed: boolean;
  mid_day_drops: number;
  safe_drops: number;
  petty_cash_expenses: number;
}

export interface Product {
  id: string;
  barcode: string;
  sku_code: string;
  name: string;
  buying_price: number; // COGS
  selling_price: number;
  wholesale_price: number;
  wholesale_threshold: number; // buy Qty >= threshold to get wholesale price
  stock_level: number;
  min_stock_level: number; // alert trigger
  category_id: string;
  category_name: string;
  tax_category: "A" | "B" | "C"; // A-16% VAT, B-Exempt, C-Zero Rated
  parent_id?: string; // For parent-child stock linking (wholesale vs retail)
  child_ratio?: number; // e.g. 1 box = 24 bottles
  image?: string;
  supplier_id?: string;
}

export interface ProductBatch {
  id: string;
  product_id: string;
  batch_number: string;
  expiry_date: string;
  quantity_received: number;
  manufacturing_date: string;
}

export interface TransactionLine {
  id: string;
  tx_id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price_at_sale: number;
  line_discount: number;
  calculated_tax: number;
  tax_category: "A" | "B" | "C";
}

export interface Transaction {
  id: string;
  receipt_number: string;
  subtotal: number;
  tax_amount: number;
  grand_total: number;
  payment_method: "Cash" | "M-Pesa" | "Split" | "Corporate PO";
  cash_paid: number;
  mpesa_paid: number;
  change_due: number;
  user_id: string;
  cashier_name: string;
  shift_id: string;
  timestamp: string;
  status: "Completed" | "Refunded" | "Voided";
  is_synced: boolean;
  sync_attempts: number;
  error_log?: string;
  kra_qr_code?: string;
  e_tims_signature?: string;
  buyer_kra_pin?: string;
  lines: TransactionLine[];
  mpesa_code?: string;
}

export interface MpesaLog {
  id: string;
  checkout_request_id: string;
  merchant_request_id: string;
  mpesa_code: string | null;
  status: "Pending" | "Success" | "Failed" | "Cancelled";
  tx_id: string | null;
  phone: string;
  amount: number;
  timestamp: string;
  error_message?: string;
}

export interface AuditVoid {
  id: string;
  timestamp: string;
  item_removed_name: string;
  quantity_before: number;
  action_taken: "Cart Item Delete" | "Full Cart Wipe" | "Price Override";
  user_id: string;
  cashier_name: string;
  tx_id?: string;
  reason: string;
}

export interface PettyCashLog {
  id: string;
  amount: number;
  reason: string;
  timestamp: string;
  user_id: string;
  cashier_name: string;
  shift_id: string;
}

export interface SafeDropLog {
  id: string;
  amount: number;
  timestamp: string;
  cashier_id: string;
  cashier_name: string;
  manager_id: string;
  manager_name: string;
  shift_id: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  balance_due: number;
}

export interface PurchaseOrder {
  id: string;
  supplier_id: string;
  supplier_name: string;
  date: string;
  status: "Draft" | "Sent" | "Received";
  items: {
    product_id: string;
    product_name: string;
    quantity: number;
    unit_cost: number;
  }[];
  total_amount: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  loyalty_points: number;
  credit_balance: number;
  birthday?: string; // YYYY-MM-DD
}

export interface MpesaCredentials {
  tillNumber: string;
  consumerKey: string;
  consumerSecret: string;
  passkey: string;
  callbackUrl: string;
  isEnabled: boolean;
}

export interface ReceiptTemplate {
  logoText: string;
  shopName: string;
  kraPin: string;
  address: string;
  phone: string;
  footerText: string;
}

export interface SyncAttempt {
  id: string;
  timestamp: string;
  batch_size: number;
  success: boolean;
  error?: string;
}
