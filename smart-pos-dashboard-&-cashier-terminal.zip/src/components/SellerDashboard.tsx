import React, { useState, useEffect, useRef } from "react";
import { 
  User, Shift, Product, Transaction, TransactionLine, 
  Customer, MpesaLog, AuditVoid, ReceiptTemplate, SyncAttempt 
} from "../types";
import { offlineStore, checkNetworkStatus } from "../utils/offlineStore";
import { 
  Scan, ShoppingCart, Search, CreditCard, DollarSign, ArrowRight, 
  RotateCcw, Trash2, Layers, UserCheck, ShieldAlert, Wifi, WifiOff, 
  Clock, Plus, Minus, CheckCircle, X, ChevronRight, Play, Eye, Ticket,
  ExternalLink
} from "lucide-react";
import LiveIntegrationSidebar from "./LiveIntegrationSidebar";

interface SellerDashboardProps {
  currentUser: User;
  onLogout: () => void;
  activeShift: Shift | null;
  onOpenShift: (float: number) => void;
  onCloseShift: (cashCount: number, mpesaCount: number) => void;
  products: Product[];
  onRefreshProducts: () => void;
  onRecordVoid: (voidLog: Omit<AuditVoid, "id" | "timestamp">) => void;
  onAddTransaction: (tx: Transaction) => void;
}

interface ParkedCart {
  id: string;
  label: string;
  items: CartItem[];
  timestamp: string;
}

interface CartItem {
  product: Product;
  quantity: number;
  discount: number; // percentage
}

export default function SellerDashboard({
  currentUser,
  onLogout,
  activeShift,
  onOpenShift,
  onCloseShift,
  products,
  onRefreshProducts,
  onRecordVoid,
  onAddTransaction
}: SellerDashboardProps) {
  // Network & Sync state
  const [isOnline, setIsOnline] = useState(true);
  const [syncStatus, setSyncStatus] = useState<"idle" | "syncing" | "success" | "error">("idle");
  const [offlineCount, setOfflineCount] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Cart & Input states
  const [searchQuery, setSearchQuery] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCartIndex, setActiveCartIndex] = useState<number | null>(null); // Parked index
  const [parkedCarts, setParkedCarts] = useState<ParkedCart[]>([]);
  
  // Checkout modal states
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"Cash" | "M-Pesa" | "Split">("Cash");
  const [cashReceived, setCashReceived] = useState<string>("");
  const [mpesaPhoneNumber, setMpesaPhoneNumber] = useState("");
  const [mpesaStatus, setMpesaStatus] = useState<"idle" | "sending" | "waiting" | "success" | "failed">("idle");
  const [mpesaCountdown, setMpesaCountdown] = useState(60);
  const [mpesaTransactionCode, setMpesaTransactionCode] = useState("");
  const [mpesaErrorMessage, setMpesaErrorMessage] = useState("");
  
  // Customer & Loyalty states
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerSearch, setCustomerSearch] = useState("");
  const [b2bKraPin, setB2bKraPin] = useState("");
  const [useLoyaltyPoints, setUseLoyaltyPoints] = useState(false);

  // Shift & Cash control states
  const [floatAmount, setFloatAmount] = useState("2000");
  const [closingCash, setClosingCash] = useState("");
  const [closingMpesa, setClosingMpesa] = useState("");
  const [shiftReportOpen, setShiftReportOpen] = useState(false);
  const [closedShiftData, setClosedShiftData] = useState<Shift | null>(null);

  // Price check & Return utilities
  const [priceCheckModal, setPriceCheckModal] = useState(false);
  const [priceCheckProduct, setPriceCheckProduct] = useState<Product | null>(null);
  const [refundModalOpen, setRefundModalOpen] = useState(false);
  const [refundReceiptNum, setRefundReceiptNum] = useState("");
  const [refundTx, setRefundTx] = useState<Transaction | null>(null);
  const [refundLinesToReturn, setRefundLinesToReturn] = useState<Record<string, number>>({});
  const [refundReason, setRefundReason] = useState("Faulty Product");
  
  // Manager override states
  const [overrideModal, setOverrideModal] = useState<{ isOpen: boolean; action: () => void; requiredRole: string; reason: string }>({
    isOpen: false,
    action: () => {},
    requiredRole: "Admin",
    reason: ""
  });
  const [overridePin, setOverridePin] = useState("");
  const [overrideError, setOverrideError] = useState("");

  // Refs
  const scanInputRef = useRef<HTMLInputElement>(null);
  const mpesaTimerRef = useRef<NodeJS.Timeout | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Auto-focus barcode scanner hook
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore shortcut handler if typing in specific text fields
      const activeEl = document.activeElement;
      const isInput = activeEl && (activeEl.tagName === "INPUT" || activeEl.tagName === "TEXTAREA");

      if (e.key === "F1" && !checkoutModalOpen) {
        e.preventDefault();
        if (cart.length > 0) {
          setPaymentMethod("Cash");
          setCheckoutModalOpen(true);
        }
      } else if (e.key === "F2" && !checkoutModalOpen) {
        e.preventDefault();
        if (cart.length > 0 && isOnline) {
          setPaymentMethod("M-Pesa");
          setCheckoutModalOpen(true);
        }
      } else if (e.key === "F3") {
        e.preventDefault();
        setPriceCheckModal(true);
      } else if (e.key === "F4" || e.key === "Escape") {
        e.preventDefault();
        closeAllModals();
      } else if (e.key === "Space" && e.ctrlKey && !checkoutModalOpen) {
        e.preventDefault();
        if (cart.length > 0) setCheckoutModalOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [cart, checkoutModalOpen, isOnline]);

  // Keep scanner focused
  useEffect(() => {
    if (activeShift && !checkoutModalOpen && !priceCheckModal && !refundModalOpen && !overrideModal.isOpen) {
      scanInputRef.current?.focus();
    }
  }, [activeShift, checkoutModalOpen, priceCheckModal, refundModalOpen, overrideModal.isOpen]);

  // Network Heartbeat
  useEffect(() => {
    const interval = setInterval(async () => {
      const online = await checkNetworkStatus();
      setIsOnline(online);
      
      const queue = offlineStore.getQueuedTransactions();
      setOfflineCount(queue.length);

      if (online && queue.length > 0 && syncStatus !== "syncing") {
        triggerSync(queue);
      }
    }, 5000);

    // Initial check
    checkNetworkStatus().then(online => {
      setIsOnline(online);
      setOfflineCount(offlineStore.getQueuedTransactions().length);
    });

    // Fetch loyalty profiles
    fetch("/api/customers").then(r => r.json()).then(setCustomers).catch(console.error);

    return () => clearInterval(interval);
  }, [syncStatus]);

  // Handle Offline Synchronization
  const triggerSync = async (queue: Transaction[]) => {
    setSyncStatus("syncing");
    try {
      const res = await fetch("/api/transactions/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ batch: queue })
      });
      const data = await res.json();
      if (data.success) {
        setSyncStatus("success");
        offlineStore.removeTransactionsFromQueue(queue.map(t => t.id));
        setOfflineCount(0);
        offlineStore.addSyncLog({ success: true, batch_size: queue.length });
        onRefreshProducts();
      } else {
        setSyncStatus("error");
        offlineStore.addSyncLog({ success: false, batch_size: queue.length, error: "Sync failed" });
      }
    } catch (err: any) {
      setSyncStatus("error");
      offlineStore.addSyncLog({ success: false, batch_size: queue.length, error: err.message });
    }
  };

  const closeAllModals = () => {
    setCheckoutModalOpen(false);
    setPriceCheckModal(false);
    setRefundModalOpen(false);
    setOverrideModal(prev => ({ ...prev, isOpen: false }));
    setOverridePin("");
    setOverrideError("");
    setPriceCheckProduct(null);
    if (mpesaTimerRef.current) {
      clearInterval(mpesaTimerRef.current);
    }
    setMpesaStatus("idle");
  };

  // Barcode / Text Search input submission
  const handleScannerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    let scanVal = searchQuery.trim();
    let qtyMultiplier = 1;

    // Check for Leading Asterisk Quantifier, e.g. "5*6100000001"
    const match = scanVal.match(/^(\d+)\*(.*)$/);
    if (match) {
      qtyMultiplier = parseInt(match[1]);
      scanVal = match[2];
    }

    // Try finding product by barcode first, then SKU, then Name
    const product = products.find(
      p => p.barcode === scanVal || p.sku_code.toLowerCase() === scanVal.toLowerCase()
    ) || products.find(p => p.name.toLowerCase().includes(scanVal.toLowerCase()));

    if (product) {
      addProductToCart(product, qtyMultiplier);
    } else {
      alert(`Product "${scanVal}" not found. Try again or check product grid.`);
    }
    setSearchQuery("");
  };

  // Cart modifier helpers
  const addProductToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const idx = prev.findIndex(item => item.product.id === product.id);
      if (idx > -1) {
        const updated = [...prev];
        updated[idx].quantity += quantity;
        return updated;
      } else {
        return [...prev, { product, quantity, discount: 0 }];
      }
    });
  };

  const updateCartQty = (productId: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  // Cart item removal with security restrictions
  const removeCartItem = (item: CartItem) => {
    const performRemoval = () => {
      setCart(prev => prev.filter(i => i.product.id !== item.product.id));
      onRecordVoid({
        item_removed_name: item.product.name,
        quantity_before: item.quantity,
        action_taken: "Cart Item Delete",
        user_id: currentUser.id,
        cashier_name: currentUser.name,
        reason: "Cashier item void"
      });
    };

    // If seller role, require manager PIN for item deletion
    if (currentUser.role === "Seller") {
      setOverrideModal({
        isOpen: true,
        action: performRemoval,
        requiredRole: "Admin",
        reason: `Authorize deletion of ${item.product.name} from active cart`
      });
    } else {
      performRemoval();
    }
  };

  const handleClearCart = () => {
    const clearAction = () => {
      setCart([]);
      setSelectedCustomer(null);
      setUseLoyaltyPoints(false);
      setB2bKraPin("");
      onRecordVoid({
        item_removed_name: "FULL BASKET CLEAR",
        quantity_before: cart.reduce((acc, i) => acc + i.quantity, 0),
        action_taken: "Full Cart Wipe",
        user_id: currentUser.id,
        cashier_name: currentUser.name,
        reason: "Cashier triggered full cart wipe"
      });
    };

    if (currentUser.role === "Seller") {
      setOverrideModal({
        isOpen: true,
        action: clearAction,
        requiredRole: "Admin",
        reason: "Authorize full cart wipe-out"
      });
    } else {
      if (confirm("Are you sure you want to completely clear the cart?")) {
        clearAction();
      }
    }
  };

  // Manager Override PIN Processing
  const handleOverridePINSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setOverrideError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin: overridePin })
      });
      const data = await res.json();
      if (data.success && data.user.role === overrideModal.requiredRole) {
        // PIN verified! Execute the pending callback
        overrideModal.action();
        closeAllModals();
      } else {
        setOverrideError("Access Denied: Incorrect Manager PIN");
      }
    } catch {
      setOverrideError("Error verifying security PIN");
    }
  };

  // Multi-cart Parking mechanics
  const handleParkCart = () => {
    if (cart.length === 0) return;
    const label = prompt("Enter custom label for this cart:", `Basket ${parkedCarts.length + 1}`);
    if (label) {
      const newParked: ParkedCart = {
        id: "pc_" + Date.now(),
        label,
        items: cart,
        timestamp: new Date().toLocaleTimeString()
      };
      setParkedCarts(prev => [...prev, newParked]);
      setCart([]);
      setSelectedCustomer(null);
    }
  };

  const handleRecallCart = (parked: ParkedCart) => {
    if (cart.length > 0) {
      if (!confirm("Overwrite current cart with the parked selection?")) return;
    }
    setCart(parked.items);
    setParkedCarts(prev => prev.filter(p => p.id !== parked.id));
  };

  // Calculation metrics
  const getSubtotal = () => {
    return cart.reduce((acc, item) => {
      // Dynamic wholesale pricing check
      const usesWholesale = item.product.wholesale_threshold > 0 && item.quantity >= item.product.wholesale_threshold;
      const unitPrice = usesWholesale ? item.product.wholesale_price : item.product.selling_price;
      const lineCost = unitPrice * item.quantity;
      const discountAmount = (lineCost * item.discount) / 100;
      return acc + (lineCost - discountAmount);
    }, 0);
  };

  const getTaxAmount = () => {
    return cart.reduce((acc, item) => {
      // Products in Tax Category A pay 16% VAT, B is exempt (0%), C is zero-rated (0%)
      if (item.product.tax_category === "A") {
        const usesWholesale = item.product.wholesale_threshold > 0 && item.quantity >= item.product.wholesale_threshold;
        const price = usesWholesale ? item.product.wholesale_price : item.product.selling_price;
        const lineTotal = price * item.quantity * (1 - item.discount / 100);
        // VAT inclusive calculation: VAT = Total - (Total / 1.16)
        return acc + (lineTotal - (lineTotal / 1.16));
      }
      return acc;
    }, 0);
  };

  const getGrandTotal = () => {
    let total = getSubtotal();
    if (useLoyaltyPoints && selectedCustomer) {
      // Redeme points: 1 point = KSh 1.00 discount
      const maxPtsDiscount = Math.min(selectedCustomer.loyalty_points, total);
      total -= maxPtsDiscount;
    }
    return Math.max(0, total);
  };

  const getChangeDue = () => {
    const received = parseFloat(cashReceived || "0");
    const grand = getGrandTotal();
    return Math.max(0, received - grand);
  };

  // checkout submission
  const handleFinalizeCheckout = async () => {
    if (cart.length === 0 || !activeShift) return;

    const total = getGrandTotal();
    const sub = getSubtotal();
    const tax = getTaxAmount();

    // Verification step
    if (paymentMethod === "Cash") {
      const received = parseFloat(cashReceived || "0");
      if (received < total) {
        alert("Received cash is less than total due");
        return;
      }
    }

    const txPayload: Transaction = {
      id: "tx_" + Date.now(),
      receipt_number: "RCPT-" + Math.floor(100000 + Math.random() * 900000),
      subtotal: sub,
      tax_amount: tax,
      grand_total: total,
      payment_method: paymentMethod === "Split" ? "Split" : (paymentMethod === "M-Pesa" ? "M-Pesa" : "Cash"),
      cash_paid: paymentMethod === "Cash" ? total : 0,
      mpesa_paid: paymentMethod === "M-Pesa" ? total : 0,
      change_due: paymentMethod === "Cash" ? parseFloat(cashReceived || "0") - total : 0,
      user_id: currentUser.id,
      cashier_name: currentUser.name,
      shift_id: activeShift.id,
      timestamp: new Date().toISOString(),
      status: "Completed",
      is_synced: isOnline,
      sync_attempts: 1,
      buyer_kra_pin: b2bKraPin || undefined,
      mpesa_code: paymentMethod === "M-Pesa" ? mpesaTransactionCode || undefined : undefined,
      lines: cart.map((item, idx) => ({
        id: `line_${Date.now()}_${idx}`,
        tx_id: "",
        product_id: item.product.id,
        product_name: item.product.name,
        quantity: item.quantity,
        unit_price_at_sale: item.product.selling_price,
        line_discount: item.discount,
        calculated_tax: item.product.tax_category === "A" ? (item.product.selling_price * item.quantity * 0.16) / 1.16 : 0,
        tax_category: item.product.tax_category
      }))
    };

    if (isOnline) {
      try {
        const res = await fetch("/api/transactions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ transaction: txPayload })
        });
        const data = await res.json();
        if (data.success) {
          onAddTransaction(data.transaction);
          alert(`Transaction ${data.transaction.receipt_number} completed successfully!`);
          
          // Trigger simulated WhatsApp receipt if loyalty customer with phone is attached
          if (selectedCustomer) {
            fetch("/api/whatsapp/send-receipt", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                phone: selectedCustomer.phone,
                receiptNumber: data.transaction.receipt_number,
                text: `KSh ${total} transaction completed! Your receipt has been signed by eTIMS.`
              })
            });
          }
        }
      } catch {
        offlineStore.saveTransactionOffline(txPayload);
        alert("Saved transaction locally (Working Offline)");
      }
    } else {
      offlineStore.saveTransactionOffline(txPayload);
      alert("No connection. Transaction saved to offline queue!");
    }

    // Reset checkout state
    setCart([]);
    setSelectedCustomer(null);
    setUseLoyaltyPoints(false);
    setB2bKraPin("");
    closeAllModals();
  };

  // Safaricom Daraja STK Push trigger
  const handleSendSTKPush = async () => {
    if (!mpesaPhoneNumber) return;
    setMpesaStatus("sending");
    setMpesaErrorMessage("");

    // Standardize phone format (e.g. 0712345678 -> 254712345678)
    let cleanPhone = mpesaPhoneNumber.replace(/\s+/g, "").replace("+", "");
    if (cleanPhone.startsWith("0")) {
      cleanPhone = "254" + cleanPhone.slice(1);
    }

    try {
      const res = await fetch("/api/mpesa/stk-push", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: cleanPhone,
          amount: getGrandTotal()
        })
      });
      const data = await res.json();
      if (data.success) {
        setMpesaStatus("waiting");
        setMpesaCountdown(60);
        pollSTKStatus(data.checkoutRequestId);
      } else {
        setMpesaStatus("failed");
        setMpesaErrorMessage(data.message);
      }
    } catch {
      setMpesaStatus("failed");
      setMpesaErrorMessage("Failed to establish Daraja socket connection");
    }
  };

  // Status Polling helper
  const pollSTKStatus = (checkoutId: string) => {
    let attempts = 0;
    mpesaTimerRef.current = setInterval(async () => {
      attempts++;
      setMpesaCountdown(prev => (prev > 0 ? prev - 1 : 0));

      try {
        const res = await fetch(`/api/mpesa/status/${checkoutId}`);
        const data = await res.json();
        
        if (data.status === "Success") {
          setMpesaStatus("success");
          setMpesaTransactionCode(data.mpesa_code);
          clearInterval(mpesaTimerRef.current!);
          
          // Complete payment
          setTimeout(() => {
            handleFinalizeCheckout();
          }, 1500);
        } else if (data.status === "Cancelled" || data.status === "Failed") {
          setMpesaStatus("failed");
          setMpesaErrorMessage(data.error_message || "STK Push declined by customer");
          clearInterval(mpesaTimerRef.current!);
        }
      } catch {
        // ignore err and continue polling
      }

      if (attempts >= 12) { // 60 seconds timeout (5s interval * 12)
        setMpesaStatus("failed");
        setMpesaErrorMessage("PIN Prompt Timeout: Customer did not enter credentials in time");
        clearInterval(mpesaTimerRef.current!);
      }
    }, 5000);
  };

  // Price check trigger
  const handleOnFlyPriceCheck = (barcode: string) => {
    const prod = products.find(p => p.barcode === barcode);
    if (prod) {
      setPriceCheckProduct(prod);
    } else {
      setPriceCheckProduct(null);
    }
  };

  // Return/Refund Receipts fetcher
  const handleRefundSearch = async () => {
    try {
      const res = await fetch("/api/transactions");
      const txs: Transaction[] = await res.json();
      const match = txs.find(t => t.receipt_number === refundReceiptNum);
      if (match) {
        setRefundTx(match);
        // Preset return quantities to 0
        const initialRet: Record<string, number> = {};
        match.lines.forEach(l => {
          initialRet[l.product_id] = 0;
        });
        setRefundLinesToReturn(initialRet);
      } else {
        alert("Receipt number not found");
        setRefundTx(null);
      }
    } catch {
      alert("Error finding receipt");
    }
  };

  const submitRefundOrder = async () => {
    if (!refundTx) return;
    
    // Process returns payload
    alert(`Refund approved! Credit Note voucher CR-${Math.floor(1000 + Math.random() * 9000)} of value KSh ${refundTx.grand_total} generated.`);
    closeAllModals();
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-white font-sans overflow-hidden">
      {/* Top Navigation Bar */}
      <header className="flex justify-between items-center px-4 py-3 bg-slate-900 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <div className="bg-orange-500 text-white p-1.5 rounded">
            <ShoppingCart className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-md font-bold tracking-tight uppercase font-mono">METRO SMART POS <span className="text-orange-500 text-xs">v2.4</span></h1>
            <p className="text-[10px] text-slate-500 font-mono">Terminal 01 • Live Cash Desk • High Density</p>
          </div>
        </div>

        {/* Sync, Network & Mode buttons */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded bg-slate-800 text-[10px] text-slate-300 border border-slate-700">
            {isOnline ? (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                <span>ONLINE STATE</span>
              </>
            ) : (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
                <span className="text-orange-400 font-bold">WORKING OFFLINE</span>
              </>
            )}
            {offlineCount > 0 && (
              <span className="bg-orange-500 text-white px-1.5 rounded font-mono font-bold ml-1 text-[10px]">
                {offlineCount} pending
              </span>
            )}
          </div>

          <div className="text-xs">
            <span className="text-slate-400">Cashier: </span>
            <span className="font-semibold text-orange-400">{currentUser.name}</span>
          </div>

          {activeShift && (
            <div className="text-[10px] bg-slate-800 px-3 py-1 rounded text-slate-300 flex items-center gap-1.5 font-mono border border-slate-700">
              <Clock className="w-3.5 h-3.5 text-orange-400" />
              <span>Shift active: {Math.floor((Date.now() - new Date(activeShift.start_time).getTime()) / 60000)} mins</span>
            </div>
          )}

          <div className="flex items-center gap-2">
            <button 
              onClick={() => setPriceCheckModal(true)}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-750 rounded text-[11px] font-semibold flex items-center gap-1 border border-slate-700 transition"
            >
              <span>F3 Price Check</span>
            </button>
            <button 
              onClick={() => setRefundModalOpen(true)}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-750 rounded text-[11px] font-semibold flex items-center gap-1 border border-slate-700 transition"
            >
              <span>Returns & Voids</span>
            </button>
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="px-2.5 py-1.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 rounded text-[11px] font-semibold flex items-center gap-1.5 border border-emerald-500/25 transition cursor-pointer"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Live Sync & M-Pesa</span>
            </button>
            <button
              onClick={onLogout}
              className="px-2.5 py-1.5 bg-red-600 hover:bg-red-700 rounded text-[11px] font-bold transition flex items-center gap-1"
            >
              <span>Lock (F4)</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main body shift gates */}
      {!activeShift ? (
        <div className="flex-1 flex items-center justify-center bg-slate-950 p-6">
          <div className="max-w-md w-full bg-slate-900 rounded-lg border border-slate-700 p-8 shadow-2xl text-center">
            <div className="w-14 h-14 bg-orange-500/10 text-orange-500 rounded-lg flex items-center justify-center mx-auto mb-6">
              <Clock className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-bold mb-2">Initialize Store Register</h2>
            <p className="text-slate-400 text-xs mb-6">
              You must register the initial opening drawer float cash to activate the barcode scanner terminal.
            </p>
            <div className="space-y-3 mb-6">
              <label className="block text-left text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
                Opening Float Cash amount (KSh)
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold font-mono text-lg">KSh</span>
                <input
                  type="number"
                  value={floatAmount}
                  onChange={(e) => setFloatAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none rounded-lg py-3 pl-12 pr-4 text-xl font-bold font-mono"
                  placeholder="2,000"
                />
              </div>
            </div>
            <button
              onClick={() => onOpenShift(parseFloat(floatAmount || "0"))}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-lg transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Open Cash Drawer Register</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex overflow-hidden">
          {/* LEFT PANEL: Live Cart Table & Scanning controls */}
          <div className="flex-1 flex flex-col bg-slate-950 border-r border-slate-700">
            {/* Scanner Bar & Autofocus Input */}
            <form onSubmit={handleScannerSubmit} className="p-3 bg-slate-900/40 border-b border-slate-700 flex gap-2">
              <div className="relative flex-1">
                <Scan className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                <input
                  ref={scanInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Zap Barcode or type Name/SKU (e.g., 5*6100000001 adds 5 Bread)..."
                  className="w-full bg-slate-950 border border-slate-700 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none rounded-lg py-2.5 pl-10 pr-4 text-xs font-mono"
                />
              </div>
              <button 
                type="submit" 
                className="px-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-lg transition flex items-center gap-2 text-xs cursor-pointer"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Search</span>
              </button>
            </form>

            {/* Parked Carts buffer bar */}
            {parkedCarts.length > 0 && (
              <div className="bg-slate-900 border-b border-slate-800 px-3 py-2 flex items-center gap-2 overflow-x-auto">
                <Layers className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span className="text-xs text-slate-400 font-semibold mr-2">Parked Carts:</span>
                {parkedCarts.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleRecallCart(p)}
                    className="bg-slate-800 hover:bg-slate-700 text-xs px-2.5 py-1 rounded-full border border-slate-700 transition flex items-center gap-1 text-emerald-300"
                  >
                    <span>{p.label}</span>
                    <span className="text-[10px] text-slate-400">({p.items.length} items)</span>
                  </button>
                ))}
              </div>
            )}

            {/* Cart Items Table */}
            <div className="flex-1 overflow-y-auto">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 p-8">
                  <ShoppingCart className="w-16 h-16 stroke-1 mb-4 text-slate-600" />
                  <p className="text-base font-semibold">Active Cart is Empty</p>
                  <p className="text-xs text-slate-600 mt-1 max-w-xs text-center">
                    Scan products with a barcode gun or search manually. Keyboard shortcuts are active.
                  </p>
                </div>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-900 text-slate-400 text-xs font-semibold border-b border-slate-800">
                      <th className="p-3 pl-4">Item Name & SKU</th>
                      <th className="p-3 text-center w-24">Tax</th>
                      <th className="p-3 text-center w-36">Quantity</th>
                      <th className="p-3 text-right w-28">Unit Price</th>
                      <th className="p-3 text-right w-32">Total (KSh)</th>
                      <th className="p-3 text-center w-16">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900">
                    {cart.map((item) => {
                      const usesWholesale = item.product.wholesale_threshold > 0 && item.quantity >= item.product.wholesale_threshold;
                      const activePrice = usesWholesale ? item.product.wholesale_price : item.product.selling_price;
                      return (
                        <tr key={item.product.id} className="hover:bg-slate-900/40 transition">
                          <td className="p-3 pl-4">
                            <div className="font-semibold text-slate-100">{item.product.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono tracking-wider">
                              {item.product.sku_code} • {item.product.barcode}
                              {usesWholesale && <span className="ml-2 bg-purple-500/10 text-purple-400 px-1.5 py-0.5 rounded text-[9px] font-bold">WHOLESALE RATE</span>}
                            </div>
                          </td>
                          <td className="p-3 text-center">
                            <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                              Cat {item.product.tax_category} (A=16%)
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            <div className="inline-flex items-center gap-1.5 bg-slate-950 border border-slate-800 rounded-lg p-1">
                              <button
                                onClick={() => updateCartQty(item.product.id, -1)}
                                className="w-6 h-6 rounded bg-slate-900 hover:bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="text-sm font-mono font-bold w-8 text-center">{item.quantity}</span>
                              <button
                                onClick={() => updateCartQty(item.product.id, 1)}
                                className="w-6 h-6 rounded bg-slate-900 hover:bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                          <td className="p-3 text-right font-mono text-slate-300">
                            KSh {activePrice.toLocaleString()}
                          </td>
                          <td className="p-3 text-right font-mono font-semibold text-slate-100">
                            KSh {(activePrice * item.quantity).toLocaleString()}
                          </td>
                          <td className="p-3 text-center">
                            <button
                              onClick={() => removeCartItem(item)}
                              className="text-slate-500 hover:text-rose-400 p-1.5 rounded hover:bg-rose-500/10 transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>

            {/* Quick Touch Grid (Bakery, Dairy, Beverages, Spreads, etc.) */}
            <div className="h-44 bg-slate-900/40 border-t border-slate-800 p-3 flex flex-col gap-2">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-400 px-1">
                <span>⚡ Touch Selection Matrix</span>
                <span className="text-[10px] text-slate-500">Products lacking physical barcodes</span>
              </div>
              <div className="flex-1 grid grid-cols-6 gap-2 overflow-y-auto">
                {products.slice(0, 12).map((prod) => (
                  <button
                    key={prod.id}
                    onClick={() => addProductToCart(prod)}
                    className="bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl p-2 text-left flex flex-col justify-between transition group"
                  >
                    <div className="text-xs font-bold text-slate-200 line-clamp-2 group-hover:text-emerald-400 transition">
                      {prod.name}
                    </div>
                    <div className="flex justify-between items-end mt-1">
                      <span className="text-[10px] text-slate-500 font-mono">{prod.sku_code}</span>
                      <span className="text-xs font-mono font-bold text-emerald-400">KSh {prod.selling_price}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT PANEL: Checkout controls, loyalty, actions */}
          <div className="w-96 bg-slate-900 border-l border-slate-800 flex flex-col">
            {/* Customer loyalty search */}
            <div className="p-4 border-b border-slate-800 bg-slate-900/60">
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 uppercase tracking-wide">
                🔗 Attached Customer Loyalty Profile
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <UserCheck className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={customerSearch}
                    onChange={(e) => setCustomerSearch(e.target.value)}
                    placeholder="Search phone number (e.g. 25471...)"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 outline-none rounded-lg py-2 pl-9 pr-3 text-xs font-mono text-white"
                  />
                </div>
                <button
                  onClick={() => {
                    const match = customers.find(c => c.phone.includes(customerSearch));
                    if (match) {
                      setSelectedCustomer(match);
                      setCustomerSearch("");
                    } else {
                      alert("Customer profile not found");
                    }
                  }}
                  className="px-3 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-lg transition"
                >
                  Link
                </button>
              </div>

              {selectedCustomer && (
                <div className="mt-3 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex flex-col gap-1.5 relative">
                  <button
                    onClick={() => {
                      setSelectedCustomer(null);
                      setUseLoyaltyPoints(false);
                    }}
                    className="absolute right-2 top-2 text-slate-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                  <div className="text-xs font-bold text-emerald-400">{selectedCustomer.name}</div>
                  <div className="text-[11px] text-slate-400 font-mono">Mobile: +{selectedCustomer.phone}</div>
                  <div className="flex justify-between items-center mt-1 pt-1.5 border-t border-slate-800 text-[10px]">
                    <div>
                      <span className="text-slate-500">Balance points: </span>
                      <span className="font-mono font-bold text-slate-300">{selectedCustomer.loyalty_points} Pts</span>
                    </div>
                    {selectedCustomer.loyalty_points > 0 && (
                      <label className="flex items-center gap-1 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={useLoyaltyPoints}
                          onChange={(e) => setUseLoyaltyPoints(e.target.checked)}
                          className="accent-emerald-500 w-3 h-3 rounded"
                        />
                        <span className="text-slate-300">Burn points</span>
                      </label>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* B2B Capture Fields (KRA eTIMS PIN) */}
            <div className="p-3 border-b border-slate-700 bg-slate-900/30">
              <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase tracking-wide">
                🏢 Corporate B2B KRA PIN
              </label>
              <input
                type="text"
                value={b2bKraPin}
                onChange={(e) => setB2bKraPin(e.target.value.toUpperCase())}
                placeholder="P0XXXXXXXXZ (for Input VAT claims)"
                className="w-full bg-slate-950 border border-slate-700 focus:border-orange-500 outline-none rounded-md py-1.5 px-3 text-xs font-mono text-white"
              />
            </div>

            {/* Cart Summary Totals panel */}
            <div className="flex-1 p-4 flex flex-col justify-end bg-slate-950/10">
              <div className="space-y-2 mb-4">
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>Gross Basket items ({cart.reduce((acc, i) => acc + i.quantity, 0)})</span>
                  <span className="font-mono text-slate-200">KSh {getSubtotal().toLocaleString()}</span>
                </div>
                
                {useLoyaltyPoints && selectedCustomer && (
                  <div className="flex justify-between items-center text-xs text-orange-400 font-semibold">
                    <span>Loyalty Points Discount Redeme</span>
                    <span className="font-mono">- KSh {Math.min(selectedCustomer.loyalty_points, getSubtotal()).toLocaleString()}</span>
                  </div>
                )}

                <div className="flex justify-between items-center text-[10px] text-slate-500">
                  <span>KRA Sales Tax Inclusive (16% VAT)</span>
                  <span className="font-mono">KSh {getTaxAmount().toLocaleString()}</span>
                </div>

                <div className="pt-2 border-t border-slate-700 flex justify-between items-baseline">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Total Grand Due:</span>
                  <span className="text-2xl font-mono font-bold text-orange-400 tracking-tight">
                    KSh {getGrandTotal().toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Checkout actions */}
              <div className="space-y-2">
                <button
                  disabled={cart.length === 0}
                  onClick={() => {
                    setPaymentMethod("Cash");
                    setCheckoutModalOpen(true);
                  }}
                  className="w-full bg-orange-500 hover:bg-orange-600 disabled:opacity-30 text-white font-extrabold py-2.5 rounded-md transition flex items-center justify-center gap-2 cursor-pointer shadow-md text-xs"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>CASH CHECKOUT (F1)</span>
                </button>

                <button
                  disabled={cart.length === 0 || !isOnline}
                  onClick={() => {
                    setPaymentMethod("M-Pesa");
                    setCheckoutModalOpen(true);
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white font-extrabold py-2.5 rounded-md transition flex items-center justify-center gap-2 cursor-pointer shadow-md text-xs"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Safaricom M-PESA PUSH (F2)</span>
                </button>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={handleParkCart}
                    disabled={cart.length === 0}
                    className="bg-slate-800 hover:bg-slate-750 disabled:opacity-30 text-[11px] font-bold py-1.5 px-3 rounded-md border border-slate-750 transition"
                  >
                    Hold Cart
                  </button>
                  <button
                    onClick={handleClearCart}
                    disabled={cart.length === 0}
                    className="bg-red-950/30 hover:bg-red-900/40 text-red-400 disabled:opacity-30 text-[11px] font-bold py-1.5 px-3 rounded-md border border-red-900/30 transition"
                  >
                    Wipe Cart (Ctrl+Del)
                  </button>
                </div>
              </div>
            </div>

            {/* Shift management drawer closing gate */}
            <div className="p-3 bg-slate-900 border-t border-slate-700">
              <button
                onClick={() => setShiftReportOpen(true)}
                className="w-full py-1.5 bg-slate-800 hover:bg-slate-750 rounded-md text-[11px] font-bold text-slate-300 transition border border-slate-700"
              >
                End Shift & Close Register
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CHECKOUT MODAL: Cash Payment or STK Push */}
      {checkoutModalOpen && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 w-full max-w-lg shadow-2xl overflow-hidden">
            <div className="p-4 bg-slate-850 border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <CreditCard className="text-emerald-400" />
                <span>Process Payment Method</span>
              </h3>
              <button onClick={closeAllModals} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Payment Mode toggles */}
              <div className="grid grid-cols-3 gap-2">
                {["Cash", "M-Pesa", "Split"].map((mode) => (
                  <button
                    key={mode}
                    disabled={mode === "M-Pesa" && !isOnline}
                    onClick={() => setPaymentMethod(mode as any)}
                    className={`py-3 px-4 rounded-xl font-bold text-xs transition border ${
                      paymentMethod === mode
                        ? "bg-emerald-500 text-slate-950 border-emerald-400 shadow-md"
                        : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800"
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>

              <div className="p-4 bg-slate-950 rounded-xl text-center">
                <div className="text-xs text-slate-500 uppercase tracking-wide">Grand Bill Total Due</div>
                <div className="text-3xl font-mono font-black text-emerald-400 mt-1">
                  KSh {getGrandTotal().toLocaleString()}
                </div>
              </div>

              {/* PAYMENT SUB-FLOWS */}
              {paymentMethod === "Cash" && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-300">Cash Bill Received (KSh)</label>
                    <input
                      type="number"
                      autoFocus
                      value={cashReceived}
                      onChange={(e) => setCashReceived(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 outline-none rounded-xl py-3 px-4 text-2xl font-mono font-bold text-white text-center"
                      placeholder="Enter amount"
                    />
                  </div>

                  {/* Cash bill speed-tiles */}
                  <div className="grid grid-cols-4 gap-2">
                    {[100, 200, 500, 1000].map((note) => (
                      <button
                        key={note}
                        onClick={() => {
                          const current = parseFloat(cashReceived || "0");
                          setCashReceived((current + note).toString());
                        }}
                        className="py-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 rounded-lg transition"
                      >
                        + KSh {note}
                      </button>
                    ))}
                    <button
                      onClick={() => setCashReceived(getGrandTotal().toString())}
                      className="col-span-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold rounded-lg transition"
                    >
                      Exact Amount (KSh {getGrandTotal()})
                    </button>
                  </div>

                  {parseFloat(cashReceived || "0") >= getGrandTotal() && (
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center animate-fade-in">
                      <div className="text-xs text-emerald-400 font-bold">Massive Change Due Out</div>
                      <div className="text-2xl font-mono font-black text-emerald-300 mt-1">
                        KSh {getChangeDue().toLocaleString()}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {paymentMethod === "M-Pesa" && (
                <div className="space-y-4">
                  {mpesaStatus === "idle" && (
                    <div className="space-y-3">
                      <label className="block text-xs font-semibold text-slate-300">Customer Mobile Phone (Safaricom)</label>
                      <input
                        type="text"
                        autoFocus
                        value={mpesaPhoneNumber}
                        onChange={(e) => setMpesaPhoneNumber(e.target.value)}
                        placeholder="e.g. 0712345678 or 2547..."
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 outline-none rounded-xl py-3 px-4 text-xl font-mono font-bold text-center"
                      />
                      <button
                        onClick={handleSendSTKPush}
                        disabled={!mpesaPhoneNumber}
                        className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold rounded-xl transition flex items-center justify-center gap-2"
                      >
                        <Play className="w-4 h-4" />
                        <span>Send Lipa Na M-Pesa STK Prompt</span>
                      </button>
                    </div>
                  )}

                  {(mpesaStatus === "sending" || mpesaStatus === "waiting") && (
                    <div className="p-8 text-center space-y-4">
                      <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                      <div>
                        <div className="font-bold text-lg text-slate-100">
                          {mpesaStatus === "sending" ? "Initiating Safaricom Socket..." : "Awaiting Customer PIN..."}
                        </div>
                        <p className="text-xs text-slate-400 mt-1">
                          STK prompt pushed to handset. Ask customer to input their M-Pesa PIN.
                        </p>
                      </div>
                      <div className="text-2xl font-mono font-black text-cyan-400 bg-slate-950 py-2 px-4 rounded-xl inline-block">
                        {mpesaCountdown}s left
                      </div>
                    </div>
                  )}

                  {mpesaStatus === "success" && (
                    <div className="p-8 text-center space-y-3">
                      <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto" />
                      <div className="font-bold text-lg text-slate-100">Lipa Na M-Pesa Received!</div>
                      <div className="text-xs text-slate-400">
                        Safaricom Code: <span className="font-mono font-bold text-emerald-400">{mpesaTransactionCode}</span>
                      </div>
                    </div>
                  )}

                  {mpesaStatus === "failed" && (
                    <div className="space-y-3">
                      <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl text-center text-rose-400 text-sm">
                        {mpesaErrorMessage}
                      </div>
                      <button
                        onClick={() => setMpesaStatus("idle")}
                        className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-lg transition"
                      >
                        Retry M-Pesa Prompt
                      </button>
                    </div>
                  )}
                </div>
              )}

              {paymentMethod === "Split" && (
                <div className="space-y-4">
                  <p className="text-xs text-slate-400">
                    Process dual split billing (e.g., partial payment via cash, balance paid through M-Pesa).
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-300 font-semibold">Cash Portion</label>
                      <input
                        type="number"
                        className="w-full bg-slate-950 border border-slate-800 py-2.5 px-3 rounded-lg font-mono font-bold text-center"
                        placeholder="KSh 0"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-300 font-semibold">M-Pesa Portion</label>
                      <input
                        type="number"
                        className="w-full bg-slate-950 border border-slate-800 py-2.5 px-3 rounded-lg font-mono font-bold text-center"
                        placeholder="KSh 0"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-850 border-t border-slate-800 flex gap-2">
              <button
                onClick={closeAllModals}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs transition"
              >
                Cancel / Esc
              </button>
              <button
                onClick={handleFinalizeCheckout}
                disabled={paymentMethod === "Cash" && parseFloat(cashReceived || "0") < getGrandTotal()}
                className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-30 text-slate-950 font-black rounded-xl text-xs transition"
              >
                Print Receipt & Drawer Pop
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRICE CHECK MODAL */}
      {priceCheckModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Search className="text-emerald-400" />
                <span>On-The-Fly Price Check (F3)</span>
              </h3>
              <button onClick={closeAllModals} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-400">Scan or search barcode</label>
              <input
                autoFocus
                type="text"
                placeholder="Type barcode..."
                onChange={(e) => handleOnFlyPriceCheck(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 outline-none focus:border-emerald-500 py-3 px-4 rounded-xl font-mono text-center text-lg"
              />
            </div>

            {priceCheckProduct ? (
              <div className="bg-slate-950 p-4 rounded-xl space-y-3 border border-emerald-500/20">
                <div className="font-bold text-center text-emerald-400 text-lg">{priceCheckProduct.name}</div>
                <div className="grid grid-cols-2 gap-2 text-xs text-slate-400">
                  <div>SKU Code:</div>
                  <div className="text-right font-mono text-slate-200">{priceCheckProduct.sku_code}</div>
                  <div>Standard Price:</div>
                  <div className="text-right font-mono font-bold text-slate-100">KSh {priceCheckProduct.selling_price}</div>
                  <div>Wholesale rate:</div>
                  <div className="text-right font-mono text-slate-200">KSh {priceCheckProduct.wholesale_price} (min {priceCheckProduct.wholesale_threshold})</div>
                  <div>Current Shelf Stock:</div>
                  <div className="text-right font-mono text-emerald-400 font-bold">{priceCheckProduct.stock_level} units</div>
                </div>
              </div>
            ) : (
              <div className="text-center p-4 text-slate-500 text-xs">No active price lookups</div>
            )}

            <button
              onClick={closeAllModals}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl transition"
            >
              Done / Esc
            </button>
          </div>
        </div>
      )}

      {/* SHIFT RECONCILIATION MODAL */}
      {shiftReportOpen && activeShift && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 w-full max-w-lg shadow-2xl overflow-hidden">
            <div className="p-4 bg-slate-850 border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Clock className="text-emerald-400" />
                <span>Shift Closing & Reconciliation Report</span>
              </h3>
              <button onClick={() => setShiftReportOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              <p className="text-xs text-slate-400">
                You are closing the register for <span className="text-slate-100 font-bold">{currentUser.name}</span>. Input the physical counted drawers for blind reconciliation.
              </p>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-500 font-semibold uppercase">Expected Drawer Cash</div>
                  <div className="text-lg font-mono font-bold text-slate-300 mt-1">KSh {activeShift.expected_cash}</div>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-500 font-semibold uppercase">Expected M-Pesa Sales</div>
                  <div className="text-lg font-mono font-bold text-slate-300 mt-1">KSh {activeShift.expected_mpesa}</div>
                </div>
              </div>

              <div className="space-y-3.5">
                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300 font-bold">Physical Counted Cash (KSh)</label>
                  <input
                    type="number"
                    value={closingCash}
                    onChange={(e) => setClosingCash(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 py-3 px-4 rounded-xl font-mono text-lg font-bold text-white text-center focus:border-emerald-500"
                    placeholder="Count cash in drawer..."
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300 font-bold">Physical Counted M-Pesa (KSh)</label>
                  <input
                    type="number"
                    value={closingMpesa}
                    onChange={(e) => setClosingMpesa(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 py-3 px-4 rounded-xl font-mono text-lg font-bold text-white text-center focus:border-emerald-500"
                    placeholder="Check M-Pesa till balances..."
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-850 border-t border-slate-800 flex gap-2">
              <button
                onClick={() => setShiftReportOpen(false)}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs transition"
              >
                Go Back
              </button>
              <button
                onClick={() => {
                  onCloseShift(parseFloat(closingCash || "0"), parseFloat(closingMpesa || "0"));
                  setShiftReportOpen(false);
                }}
                disabled={!closingCash || !closingMpesa}
                className="flex-1 py-3 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-xl text-xs transition"
              >
                Reconcile & Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MANAGER PIN OVERRIDE MODAL */}
      {overrideModal.isOpen && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-900 rounded-2xl border border-rose-500/20 w-full max-w-sm shadow-2xl overflow-hidden p-6 space-y-4">
            <div className="text-center">
              <ShieldAlert className="w-12 h-12 text-rose-500 mx-auto mb-3" />
              <h3 className="text-lg font-black text-slate-100">Manager Security Override</h3>
              <p className="text-xs text-slate-400 mt-1">{overrideModal.reason}</p>
            </div>

            <form onSubmit={handleOverridePINSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-center text-xs font-semibold text-slate-300 uppercase">
                  Enter 4-Digit Manager PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  autoFocus
                  value={overridePin}
                  onChange={(e) => setOverridePin(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 tracking-widest text-center py-3 text-2xl font-bold font-mono outline-none rounded-xl focus:border-rose-500"
                  placeholder="••••"
                />
              </div>

              {overrideError && (
                <div className="text-xs text-rose-400 text-center font-bold">{overrideError}</div>
              )}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={closeAllModals}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-lg transition"
                >
                  Go Back / Esc
                </button>
                <button
                  type="submit"
                  disabled={overridePin.length < 4}
                  className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold rounded-lg transition"
                >
                  Authorize PIN
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RETURNS & REFUNDS MODAL */}
      {refundModalOpen && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 w-full max-w-lg shadow-2xl overflow-hidden flex flex-col h-[500px]">
            <div className="p-4 bg-slate-850 border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <RotateCcw className="text-rose-400" />
                <span>Returns & Credit Note Issuance</span>
              </h3>
              <button onClick={closeAllModals} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 flex-1 overflow-y-auto space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Scan bottom receipt barcode (e.g., RCPT-XXXXXX)"
                  value={refundReceiptNum}
                  onChange={(e) => setRefundReceiptNum(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 py-2 px-3 rounded-lg text-sm font-mono focus:border-rose-500"
                />
                <button
                  onClick={handleRefundSearch}
                  className="px-4 bg-slate-850 hover:bg-slate-800 text-xs font-bold rounded-lg border border-slate-700"
                >
                  Locate
                </button>
              </div>

              {refundTx ? (
                <div className="space-y-3.5">
                  <div className="bg-slate-950 p-3 rounded-lg text-xs space-y-1.5 border border-slate-850">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Receipt ID:</span>
                      <span className="font-mono font-bold text-slate-300">{refundTx.receipt_number}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Cashier:</span>
                      <span>{refundTx.cashier_name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Grand Total:</span>
                      <span className="font-mono text-emerald-400 font-bold">KSh {refundTx.grand_total}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Select quantities to return</div>
                    {refundTx.lines.map((line) => (
                      <div key={line.product_id} className="flex justify-between items-center bg-slate-950/60 p-2.5 rounded-lg border border-slate-900">
                        <div className="text-xs">
                          <div className="font-semibold">{line.product_name}</div>
                          <div className="text-slate-500 text-[10px]">Bought: {line.quantity} units</div>
                        </div>
                        <div className="inline-flex items-center gap-2">
                          <input
                            type="number"
                            min={0}
                            max={line.quantity}
                            value={refundLinesToReturn[line.product_id] || 0}
                            onChange={(e) => {
                              const v = Math.min(line.quantity, Math.max(0, parseInt(e.target.value || "0")));
                              setRefundLinesToReturn(prev => ({ ...prev, [line.product_id]: v }));
                            }}
                            className="bg-slate-950 border border-slate-800 w-12 text-center text-xs py-1 rounded font-mono font-bold"
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs text-slate-400">Reason for return</label>
                    <select
                      value={refundReason}
                      onChange={(e) => setRefundReason(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 text-xs py-2 px-3 rounded-lg"
                    >
                      <option>Faulty Product</option>
                      <option>Wrong Size / Spec</option>
                      <option>Customer Dissatisfied</option>
                    </select>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500 text-xs font-semibold">
                  No active transaction loaded. Scan bottom barcode.
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-850 border-t border-slate-800 flex gap-2">
              <button
                onClick={closeAllModals}
                className="flex-1 py-2.5 bg-slate-850 hover:bg-slate-800 text-xs font-semibold rounded-lg text-slate-400"
              >
                Go Back
              </button>
              <button
                onClick={submitRefundOrder}
                disabled={!refundTx || Object.values(refundLinesToReturn).every(q => q === 0)}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-lg"
              >
                Approve Return Note
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Live Integration Sidebar Drawer */}
      <LiveIntegrationSidebar 
        products={products}
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
      />
    </div>
  );
}
