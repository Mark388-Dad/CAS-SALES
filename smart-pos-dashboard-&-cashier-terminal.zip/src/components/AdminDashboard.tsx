import React, { useState, useEffect } from "react";
import { 
  User, Shift, Product, ProductBatch, Transaction, AuditVoid, 
  PettyCashLog, SafeDropLog, Supplier, PurchaseOrder, Customer, SyncAttempt 
} from "../types";
import { 
  TrendingUp, BarChart3, AlertTriangle, Settings, RefreshCw, Upload, 
  Users, DollarSign, ShieldAlert, Award, FileSpreadsheet, Plus, Check,
  Mail, Calendar, ArrowRightLeft, Percent, Scale, Printer, Activity, Trash,
  Edit, Download, Eye, Search, KeyRound, ExternalLink, Link
} from "lucide-react";
import LiveIntegrationSidebar from "./LiveIntegrationSidebar";

interface AdminDashboardProps {
  currentUser: User;
  onLogout: () => void;
  products: Product[];
  onRefreshProducts: () => void;
  transactions: Transaction[];
  onRefreshTransactions: () => void;
  shifts: Shift[];
  auditVoids: AuditVoid[];
  onRefreshAuditVoids: () => void;
  pettyCash: PettyCashLog[];
  safeDrops: SafeDropLog[];
  suppliers: Supplier[];
  onRefreshSuppliers: () => void;
  purchaseOrders: PurchaseOrder[];
  onRefreshPO: () => void;
  customers: Customer[];
  onRefreshCustomers: () => void;
}

export default function AdminDashboard({
  currentUser,
  onLogout,
  products,
  onRefreshProducts,
  transactions,
  onRefreshTransactions,
  shifts,
  auditVoids,
  onRefreshAuditVoids,
  pettyCash,
  safeDrops,
  suppliers,
  onRefreshSuppliers,
  purchaseOrders,
  onRefreshPO,
  customers,
  onRefreshCustomers
}: AdminDashboardProps) {
  // Navigation
  const [activeTab, setActiveTab] = useState<"analytics" | "inventory" | "sellers" | "receipts" | "suppliers" | "security" | "ledger" | "settings">("analytics");
  
  // Right Sidebar State for Google Sheets & M-Pesa Live Portal
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Users/Sellers Management States
  const [usersList, setUsersList] = useState<User[]>([]);
  const [newSellerForm, setNewSellerForm] = useState({ 
    name: "", 
    pin_code: "", 
    status: "Active" as "Active" | "Inactive",
    role: "Seller" as "Admin" | "Seller"
  });
  const [editingSellerId, setEditingSellerId] = useState<string | null>(null);
  const [isSellersLoading, setIsSellersLoading] = useState(false);

  const fetchUsersList = async () => {
    setIsSellersLoading(true);
    try {
      const res = await fetch("/api/users");
      const data = await res.json();
      setUsersList(data || []);
    } catch (err) {
      console.error("Error fetching users list:", err);
    } finally {
      setIsSellersLoading(false);
    }
  };

  useEffect(() => {
    fetchUsersList();
  }, []);
  
  // Receipts & Viewing States
  const [searchReceiptQuery, setSearchReceiptQuery] = useState("");
  const [selectedReceipt, setSelectedReceipt] = useState<Transaction | null>(null);
  
  // Product editing States
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [editingProductForm, setEditingProductForm] = useState<{
    id: string;
    name: string;
    barcode: string;
    sku_code: string;
    buying_price: number;
    selling_price: number;
    wholesale_price: number;
    wholesale_threshold: number;
    stock_level: number;
    min_stock_level: number;
    category_id: string;
    category_name: string;
    tax_category: "A" | "B" | "C";
  } | null>(null);

  // Sync editingProductForm state when editProduct is selected
  useEffect(() => {
    if (editProduct) {
      setEditingProductForm({
        id: editProduct.id,
        name: editProduct.name,
        barcode: editProduct.barcode,
        sku_code: editProduct.sku_code,
        buying_price: editProduct.buying_price,
        selling_price: editProduct.selling_price,
        wholesale_price: editProduct.wholesale_price,
        wholesale_threshold: editProduct.wholesale_threshold,
        stock_level: editProduct.stock_level,
        min_stock_level: editProduct.min_stock_level,
        category_id: editProduct.category_id,
        category_name: editProduct.category_name,
        tax_category: editProduct.tax_category,
      });
    } else {
      setEditingProductForm(null);
    }
  }, [editProduct]);

  // Create state variables for forms and dialogs
  const [newProduct, setNewProduct] = useState({
    name: "", barcode: "", sku_code: "", buying_price: 0, selling_price: 0,
    wholesale_price: 0, wholesale_threshold: 10, stock_level: 0, min_stock_level: 5,
    category_id: "cat_general", category_name: "General", tax_category: "A" as "A"|"B"|"C",
    parent_id: "", child_ratio: 1
  });
  const [newSupplier, setNewSupplier] = useState({ name: "", phone: "", email: "", address: "", balance_due: 0 });
  const [newBatch, setNewBatch] = useState({ product_id: "", batch_number: "", expiry_date: "", quantity_received: 0, manufacturing_date: "" });
  const [bulkCsvInput, setBulkCsvInput] = useState("");
  
  // Settings state variables
  const [mpesaSettings, setMpesaSettings] = useState({
    tillNumber: "5123456", consumerKey: "uXyZ123DarajaConsumerKeyAwesome",
    consumerSecret: "SecretDarajaCredentialsXyz9876", passkey: "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919",
    callbackUrl: "https://api.myretailpos.co.ke/api/mpesa/callback", isEnabled: true
  });
  const [receiptSettings, setReceiptSettings] = useState({
    logoText: "🛒 METRO SMART SUPERMARKET", shopName: "Metro Smart Retail Ltd",
    kraPin: "P051234567Z", address: "Moi Avenue, Nairobi, Kenya",
    phone: "+254 700 123 456", footerText: "THANK YOU FOR SHOPPING WITH US! GOODS ONCE SOLD ARE NOT RETURNABLE UNLESS DEFECTIVE."
  });

  // Filters
  const [dateFilter, setDateFilter] = useState("all"); // all, today, weekly
  const [receiptDateFilter, setReceiptDateFilter] = useState("all"); // all, today
  const [expiryFilterDays, setExpiryFilterDays] = useState(60); // 30, 60, 90 days

  // Peripheral Diagnostic Indicators
  const [peripherals, setPeripherals] = useState({
    scanner: "Connected", printer: "Connected", scale: "Connected", internet: "Connected"
  });

  useEffect(() => {
    // Fetch system settings
    fetch("/api/settings")
      .then(r => r.json())
      .then(d => {
        if (d.settings) {
          setMpesaSettings(d.settings.mpesa);
          setReceiptSettings(d.settings.receipt);
        }
      })
      .catch(console.error);
  }, []);

  // Update Settings handler
  const saveSettings = async () => {
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mpesa: mpesaSettings, receipt: receiptSettings })
      });
      const data = await res.json();
      if (data.success) {
        alert("Configuration updated successfully on live server!");
      }
    } catch {
      alert("Error updating server configuration");
    }
  };

  // Bulk CSV Upload handler
  const handleBulkCsvUpload = async () => {
    if (!bulkCsvInput.trim()) return;
    const lines = bulkCsvInput.trim().split("\n");
    const parsedProducts = [];

    // Skip header line if it contains metadata
    const startIdx = lines[0].toLowerCase().includes("name") ? 1 : 0;

    for (let i = startIdx; i < lines.length; i++) {
      const parts = lines[i].split(",");
      if (parts.length >= 5) {
        parsedProducts.push({
          name: parts[0]?.trim(),
          barcode: parts[1]?.trim(),
          sku_code: parts[2]?.trim(),
          buying_price: parseFloat(parts[3]?.trim() || "0"),
          selling_price: parseFloat(parts[4]?.trim() || "0"),
          wholesale_price: parseFloat(parts[5]?.trim() || parts[4]?.trim() || "0"),
          stock_level: parseInt(parts[6]?.trim() || "0"),
          min_stock_level: parseInt(parts[7]?.trim() || "5"),
          category_name: parts[8]?.trim() || "General",
          tax_category: parts[9]?.trim() || "A"
        });
      }
    }

    if (parsedProducts.length === 0) {
      alert("No valid CSV rows parsed. Check columns: Name,Barcode,SKU,BuyingPrice,SellingPrice,...");
      return;
    }

    try {
      const res = await fetch("/api/products/bulk-upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ products: parsedProducts })
      });
      const d = await res.json();
      if (d.success) {
        alert(`Successfully uploaded ${d.addedCount} new products and updated ${d.updatedCount} existing entries!`);
        setBulkCsvInput("");
        onRefreshProducts();
      }
    } catch {
      alert("Error conducting bulk CSV update");
    }
  };

  // Add Manual Product handler
  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newProduct)
      });
      const data = await res.json();
      if (data.success) {
        alert("Product registered successfully!");
        setNewProduct({
          name: "", barcode: "", sku_code: "", buying_price: 0, selling_price: 0,
          wholesale_price: 0, wholesale_threshold: 10, stock_level: 0, min_stock_level: 5,
          category_id: "cat_general", category_name: "General", tax_category: "A",
          parent_id: "", child_ratio: 1
        });
        onRefreshProducts();
      }
    } catch {
      alert("Error saving product");
    }
  };

  // Update Existing Product handler
  const handleUpdateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProductForm) return;
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingProductForm)
      });
      const data = await res.json();
      if (data.success) {
        alert("Product details and stock level updated successfully!");
        setEditProduct(null);
        onRefreshProducts();
      }
    } catch {
      alert("Error updating product");
    }
  };

  // Seller management handlers
  const handleCreateOrUpdateSeller = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newSellerForm.pin_code.length !== 4 || isNaN(Number(newSellerForm.pin_code))) {
      alert("PIN code must be a 4-digit number!");
      return;
    }
    try {
      const payload = editingSellerId 
        ? { id: editingSellerId, ...newSellerForm }
        : newSellerForm;

      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        alert(editingSellerId ? "Seller updated successfully!" : "New seller registered successfully!");
        setNewSellerForm({ name: "", pin_code: "", status: "Active", role: "Seller" });
        setEditingSellerId(null);
        fetchUsersList();
      }
    } catch {
      alert("Error saving seller cashier");
    }
  };

  const handleDeleteSeller = async (id: string) => {
    if (id === currentUser.id) {
      alert("You cannot delete yourself (active Administrator)!");
      return;
    }
    if (!confirm("Are you sure you want to permanently delete this seller cashier?")) return;
    try {
      const res = await fetch(`/api/users/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        alert("Seller cashier deleted successfully!");
        fetchUsersList();
      }
    } catch {
      alert("Error deleting seller cashier");
    }
  };
  const downloadReceiptTXT = (tx: Transaction) => {
    let txt = "";
    
    // Help helper functions
    const center = (str: string, width = 42) => {
      if (str.length >= width) return str.substring(0, width);
      const padding = Math.floor((width - str.length) / 2);
      return " ".repeat(padding) + str;
    };
    const rpad = (str: string, width: number) => {
      return str + " ".repeat(Math.max(0, width - str.length));
    };
    const lpad = (str: string, width: number) => {
      return " ".repeat(Math.max(0, width - str.length)) + str;
    };

    txt += center(receiptSettings.logoText) + "\n";
    txt += center(receiptSettings.shopName || "Metro Smart Supermarket") + "\n";
    txt += center(`KRA PIN: ${receiptSettings.kraPin}`) + "\n";
    txt += center(receiptSettings.address) + "\n";
    txt += center(`TEL: ${receiptSettings.phone}`) + "\n";
    txt += "=".repeat(42) + "\n";
    txt += `DATE: ${new Date(tx.timestamp).toLocaleString()}\n`;
    txt += `RECEIPT NO: ${tx.receipt_number || tx.id}\n`;
    txt += `CASHIER: ${tx.cashier_name.toUpperCase()}\n`;
    txt += "=".repeat(42) + "\n";
    txt += rpad("ITEM DESCRIPTION", 18) + lpad("QTY", 4) + lpad("PRICE", 10) + lpad("TOTAL", 10) + "\n";
    txt += "-".repeat(42) + "\n";
    tx.lines.forEach(l => {
      const itemLine = rpad(l.product_name.substring(0, 16), 18) + 
                       lpad(l.quantity.toString(), 4) + 
                       lpad(l.unit_price_at_sale.toString(), 10) + 
                       lpad((l.quantity * l.unit_price_at_sale).toString(), 10);
      txt += itemLine + "\n";
    });
    txt += "-".repeat(42) + "\n";
    txt += rpad("SUBTOTAL:", 25) + lpad(`KSh ${tx.subtotal.toLocaleString()}`, 17) + "\n";
    txt += rpad("TAX (16% VAT):", 25) + lpad(`KSh ${tx.tax_amount.toLocaleString()}`, 17) + "\n";
    txt += rpad("GRAND TOTAL DUE:", 25) + lpad(`KSh ${tx.grand_total.toLocaleString()}`, 17) + "\n";
    txt += "-".repeat(42) + "\n";
    txt += rpad("PAYMENT METHOD:", 20) + lpad(tx.payment_method.toUpperCase(), 22) + "\n";
    if (tx.payment_method === "Cash") {
      txt += rpad("CASH PAID:", 25) + lpad(`KSh ${tx.cash_paid.toLocaleString()}`, 17) + "\n";
      txt += rpad("CHANGE DUE:", 25) + lpad(`KSh ${tx.change_due.toLocaleString()}`, 17) + "\n";
    } else if (tx.payment_method === "M-Pesa") {
      txt += rpad("M-PESA REF CODE:", 15) + lpad(tx.mpesa_code || "MPESA_PUSH_LIVE", 27) + "\n";
    }
    if (tx.buyer_kra_pin) {
      txt += rpad("BUYER KRA PIN:", 18) + lpad(tx.buyer_kra_pin, 24) + "\n";
    }
    txt += "=".repeat(42) + "\n";
    txt += center("KRA e-TIMS SECURE SIGNATURE") + "\n";
    txt += center(tx.e_tims_signature || "ETIMS-SIG-PENDING-MTR") + "\n";
    txt += "=".repeat(42) + "\n";
    
    // Split footerText by lines or chunks of 42
    const footer = receiptSettings.footerText || "THANK YOU FOR SHOPPING!";
    for (let i = 0; i < footer.length; i += 42) {
      txt += center(footer.substring(i, i + 42)) + "\n";
    }
    
    const blob = new Blob([txt], { type: "text/plain;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `receipt_${tx.receipt_number || tx.id}.txt`;
    link.click();
  };

  // Add Batch with Expiry
  const handleAddBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBatch.product_id) {
      alert("Please select a product");
      return;
    }
    try {
      const res = await fetch("/api/batches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newBatch)
      });
      const data = await res.json();
      if (data.success) {
        alert("Expiry batch successfully logged! Shell stock adjusted.");
        setNewBatch({ product_id: "", batch_number: "", expiry_date: "", quantity_received: 0, manufacturing_date: "" });
        onRefreshProducts();
      }
    } catch {
      alert("Error logging batch");
    }
  };

  // Delete product
  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Are you sure you want to permanently delete this product from database?")) return;
    try {
      const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
      const d = await res.json();
      if (d.success) {
        onRefreshProducts();
      }
    } catch {
      alert("Error deleting product");
    }
  };

  // Trigger automated Purchase Order creation
  const handleAutoPO = async (product: Product) => {
    if (!product.supplier_id) {
      alert("No supplier attached to this product yet. Update supplier linkage first.");
      return;
    }
    const supp = suppliers.find(s => s.id === product.supplier_id);
    const suggestedQty = (product.min_stock_level * 3) - product.stock_level;

    try {
      const res = await fetch("/api/purchase-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          supplier_id: product.supplier_id,
          supplier_name: supp?.name || "Attached Supplier",
          total_amount: product.buying_price * suggestedQty,
          items: [{
            product_id: product.id,
            product_name: product.name,
            quantity: suggestedQty,
            unit_cost: product.buying_price
          }]
        })
      });
      const data = await res.json();
      if (data.success) {
        alert(`PO PDF created! Auto-ordered ${suggestedQty} units of ${product.name} from ${supp?.name}. Sent to ${supp?.email}`);
        onRefreshPO();
      }
    } catch {
      alert("Error creating Purchase Order");
    }
  };

  // Financial calculations
  const filteredTxs = transactions.filter(t => {
    if (dateFilter === "all") return true;
    const txDate = new Date(t.timestamp).toDateString();
    const today = new Date().toDateString();
    return txDate === today;
  });

  const grossSales = filteredTxs.reduce((acc, t) => acc + t.grand_total, 0);

  // Profit Margins (substracting buying price from selling price)
  const totalCOGS = filteredTxs.reduce((acc, t) => {
    let txCOGS = 0;
    t.lines.forEach(l => {
      const prod = products.find(p => p.id === l.product_id);
      if (prod) {
        txCOGS += prod.buying_price * l.quantity;
      }
    });
    return acc + txCOGS;
  }, 0);

  const netProfits = Math.max(0, grossSales - totalCOGS);
  const mpesaVolume = filteredTxs.filter(t => t.payment_method === "M-Pesa").reduce((acc, t) => acc + t.grand_total, 0);
  const cashVolume = filteredTxs.filter(t => t.payment_method === "Cash").reduce((acc, t) => acc + t.grand_total, 0);

  return (
    <div className="flex h-screen bg-slate-950 text-white font-sans overflow-hidden">
      {/* Sidebar Navigation */}
      <aside className="w-60 bg-slate-900 border-r border-slate-700 flex flex-col justify-between">
        <div>
          <div className="p-6 border-b border-slate-700 flex items-center gap-3">
            <div className="w-8 h-8 bg-orange-500 rounded flex items-center justify-center font-bold text-white uppercase">M</div>
            <div>
              <h1 className="font-bold tracking-tight text-md">Metro Admin <span className="text-orange-500">v2.4</span></h1>
              <span className="text-[10px] text-orange-400 font-bold font-mono">High Density Node</span>
            </div>
          </div>

          <nav className="flex-1 py-4 px-3 space-y-1">
            <div className="text-[10px] uppercase font-bold text-slate-500 px-3 mb-2">Core Operations</div>
            {[
              { id: "analytics", label: "Business Analytics", icon: BarChart3 },
              { id: "inventory", label: "Stock & Inventory", icon: FileSpreadsheet },
              { id: "sellers", label: "Sellers & PINs", icon: KeyRound },
              { id: "receipts", label: "Receipt Logs", icon: Printer },
              { id: "suppliers", label: "Suppliers & POs", icon: Users },
              { id: "security", label: "Anti-Theft Security", icon: ShieldAlert },
              { id: "ledger", label: "Safe & Petty Cash", icon: DollarSign },
              { id: "settings", label: "System Gateways", icon: Settings }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs font-semibold transition ${
                    activeTab === tab.id
                      ? "bg-slate-700 text-white shadow-md border-l-4 border-orange-500"
                      : "text-slate-400 hover:bg-slate-800 hover:text-white"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}

            <div className="pt-4 border-t border-slate-850 mt-4 px-3">
              <button
                onClick={() => setIsSidebarOpen(true)}
                className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 transition border border-emerald-500/25 cursor-pointer shadow-lg"
              >
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>Live Sync & M-Pesa</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </nav>
        </div>

        <div className="p-4 bg-slate-900 border-t border-slate-700 text-xs text-slate-400 space-y-3">
          <div className="flex justify-between items-center mb-1">
            <span>System Health</span>
            <span className="text-green-400">99.9%</span>
          </div>
          <div className="w-full bg-slate-700 h-1 rounded-full overflow-hidden">
            <div className="bg-green-500 h-full w-[99.9%]"></div>
          </div>
          <button
            onClick={onLogout}
            className="w-full py-2 bg-slate-800 hover:bg-slate-750 text-xs font-bold rounded-md transition text-red-400 text-center border border-slate-700"
          >
            Exit Control Room
          </button>
        </div>
      </aside>

      {/* Main Panel Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden bg-slate-950">
        <header className="px-6 py-3.5 bg-slate-900 border-b border-slate-700 flex justify-between items-center">
          <div>
            <h1 className="text-lg font-bold uppercase tracking-tight">
              {activeTab === "analytics" && "Financial Dashboard"}
              {activeTab === "inventory" && "Inventory Mastery Panel"}
              {activeTab === "sellers" && "Seller Cashiers & Secure PINs"}
              {activeTab === "receipts" && "Transaction Receipts Vault"}
              {activeTab === "suppliers" && "Procurement & Purchase Control"}
              {activeTab === "security" && "Employee Audit & Fraud Prevention"}
              {activeTab === "ledger" && "Vault Safe & Drawer Control"}
              {activeTab === "settings" && "Merchant Gateways & Compliance"}
            </h1>
            <p className="text-[10px] text-slate-500 font-mono">Role: {currentUser.name} • system superuser</p>
          </div>

          {/* Quick peripheral diagnostics lights */}
          <div className="flex gap-2 text-[10px] font-mono">
            {Object.entries(peripherals).map(([k, v]) => (
              <span key={k} className="bg-[#1E293B] border border-slate-700 px-2 py-1 rounded flex items-center gap-1.5">
                <span className={`w-1.5 h-1.5 rounded-full ${v === "Connected" ? "bg-green-500 animate-pulse" : "bg-red-500"}`}></span>
                <span className="text-slate-400">{k}:</span>
                <span className="text-slate-200 font-bold">{v}</span>
              </span>
            ))}
          </div>
        </header>

        {/* Content body based on active tab */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* TAB 1: ANALYTICS & REPORTS */}
          {activeTab === "analytics" && (
            <div className="space-y-5 animate-fade-in">
              {/* Date Filter selector */}
              <div className="flex gap-1.5 bg-slate-900 p-1 rounded-md w-max border border-slate-700">
                <button
                  onClick={() => setDateFilter("all")}
                  className={`px-3 py-1 text-xs font-bold rounded ${dateFilter === "all" ? "bg-slate-700 text-white" : "text-slate-400 hover:text-slate-200"}`}
                >
                  All History
                </button>
                <button
                  onClick={() => setDateFilter("today")}
                  className={`px-3 py-1 text-xs font-bold rounded ${dateFilter === "today" ? "bg-slate-700 text-white" : "text-slate-400 hover:text-slate-200"}`}
                >
                  Today Only
                </button>
              </div>

              {/* KPI cards */}
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-[#1E293B] border border-slate-700 p-4 rounded-lg shadow-sm">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Gross Sales Revenue</div>
                  <div className="text-2xl font-mono font-black text-white mt-1">KSh {grossSales.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-500 mt-1 font-mono">Based on active ledger</div>
                </div>

                <div className="bg-[#1E293B] border border-slate-700 p-4 rounded-lg shadow-sm">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Net Profit Margin</div>
                  <div className="text-2xl font-mono font-black text-orange-400 mt-1">KSh {netProfits.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-500 mt-1 font-mono">COGS (buying price) deducted</div>
                </div>

                <div className="bg-[#1E293B] border border-slate-700 p-4 rounded-lg shadow-sm">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">M-Pesa Collections</div>
                  <div className="text-2xl font-mono font-black text-blue-400 mt-1">KSh {mpesaVolume.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-500 mt-1 font-mono">Safaricom Daraja API logs</div>
                </div>

                <div className="bg-[#1E293B] border border-slate-700 p-4 rounded-lg shadow-sm">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Cash In Register</div>
                  <div className="text-2xl font-mono font-black text-emerald-400 mt-1">KSh {cashVolume.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-500 mt-1 font-mono">Physical drawer receipts</div>
                </div>
              </div>

              {/* Tax reports & eTIMS automated sync validation summaries */}
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                  <h3 className="text-sm font-bold uppercase tracking-wide border-b border-slate-800 pb-3 mb-4 text-slate-300">
                    KRA eTIMS statutory compliance ledger
                  </h3>
                  <div className="space-y-3.5">
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>KRA PIN Registered:</span>
                      <span className="font-mono font-bold text-slate-200">{receiptSettings.kraPin}</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Total collectable VAT (Category A - 16%):</span>
                      <span className="font-mono text-emerald-400 font-bold">
                        KSh {filteredTxs.reduce((acc, t) => acc + t.tax_amount, 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>eTIMS automatic sync status rate:</span>
                      <span className="bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded text-[10px]">
                        100% SUCCESS SYNCED
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                  <h3 className="text-sm font-bold uppercase tracking-wide border-b border-slate-800 pb-3 mb-4 text-slate-300">
                    Highest Earnings & Fast Moving Velocity
                  </h3>
                  {products.slice(0, 3).map((prod, idx) => (
                    <div key={prod.id} className="flex justify-between items-center py-2 border-b border-slate-800/40 last:border-0">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xs bg-slate-950 px-2 py-1 rounded text-slate-500 font-mono font-bold">#0{idx+1}</span>
                        <div className="text-xs font-semibold">{prod.name}</div>
                      </div>
                      <span className="text-xs font-mono text-emerald-400 font-bold">KSh {prod.selling_price}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: INVENTORY */}
          {activeTab === "inventory" && (
            <div className="space-y-6 animate-fade-in">
              {/* Product Controls Toolbar */}
              <div className="grid grid-cols-3 gap-6">
                {/* Manual Product Registration */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 text-slate-300 uppercase">
                    Register New Product
                  </h3>
                  <form onSubmit={handleAddProduct} className="space-y-3 text-xs">
                    <div className="space-y-1">
                      <label>Product Title Name</label>
                      <input
                        type="text"
                        required
                        value={newProduct.name}
                        onChange={(e) => setNewProduct(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg"
                        placeholder="e.g. Broadways Bread 400g"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label>Barcode ID</label>
                        <input
                          type="text"
                          required
                          value={newProduct.barcode}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, barcode: e.target.value }))}
                          className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono"
                          placeholder="6100..."
                        />
                      </div>
                      <div className="space-y-1">
                        <label>SKU Code</label>
                        <input
                          type="text"
                          required
                          value={newProduct.sku_code}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, sku_code: e.target.value }))}
                          className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono"
                          placeholder="SKU-..."
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="space-y-1">
                        <label>Buying (COGS)</label>
                        <input
                          type="number"
                          required
                          value={newProduct.buying_price || ""}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, buying_price: parseFloat(e.target.value || "0") }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-2 rounded-lg"
                        />
                      </div>
                      <div className="space-y-1">
                        <label>Selling Price</label>
                        <input
                          type="number"
                          required
                          value={newProduct.selling_price || ""}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, selling_price: parseFloat(e.target.value || "0") }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-2 rounded-lg"
                        />
                      </div>
                      <div className="space-y-1">
                        <label>Wholesale Price</label>
                        <input
                          type="number"
                          required
                          value={newProduct.wholesale_price || ""}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, wholesale_price: parseFloat(e.target.value || "0") }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-2 rounded-lg"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label>Tax Bracket</label>
                        <select
                          value={newProduct.tax_category}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, tax_category: e.target.value as any }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-2 rounded-lg"
                        >
                          <option value="A">Cat A - 16% VAT</option>
                          <option value="B">Cat B - Exempt (0%)</option>
                          <option value="C">Cat C - Zero-Rated</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label>Initial Stock Level</label>
                        <input
                          type="number"
                          value={newProduct.stock_level || ""}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, stock_level: parseInt(e.target.value || "0") }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-2 rounded-lg"
                        />
                      </div>
                    </div>

                    {/* Parent-Child linking configuration */}
                    <div className="p-3 bg-slate-950 rounded-xl space-y-2 border border-slate-800">
                      <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Parent-Child Stock Linking</div>
                      <div className="grid grid-cols-2 gap-2 text-[10px]">
                        <div>
                          <label>Bulk Parent Product</label>
                          <select
                            value={newProduct.parent_id}
                            onChange={(e) => setNewProduct(prev => ({ ...prev, parent_id: e.target.value }))}
                            className="w-full bg-slate-900 border border-slate-800 rounded p-1"
                          >
                            <option value="">None (Independent)</option>
                            {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                          </select>
                        </div>
                        <div>
                          <label>Child Ratio (e.g. 24)</label>
                          <input
                            type="number"
                            value={newProduct.child_ratio}
                            onChange={(e) => setNewProduct(prev => ({ ...prev, child_ratio: parseInt(e.target.value || "1") }))}
                            className="w-full bg-slate-900 border border-slate-800 rounded p-1"
                          />
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-lg transition text-xs"
                    >
                      Add product to database
                    </button>
                  </form>
                </div>

                {/* Bulk CSV spreadsheet parsing */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 text-slate-300 uppercase">
                    Bulk CSV Spreadsheet Upload
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    Paste raw spreadsheet lines in standard CSV column formats:<br/>
                    <span className="font-mono text-emerald-400 text-[9px]">Name,Barcode,SKU,BuyingPrice,SellingPrice,WholesalePrice,Stock,MinStock</span>
                  </p>
                  <textarea
                    rows={8}
                    value={bulkCsvInput}
                    onChange={(e) => setBulkCsvInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 p-3 rounded-lg font-mono text-xs outline-none focus:border-emerald-500 text-white"
                    placeholder="Fresh Milk,6100000002,MILK-01,58,70,66,12,15,Dairy,A"
                  />
                  <button
                    onClick={handleBulkCsvUpload}
                    className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/20 font-black rounded-lg transition text-xs"
                  >
                    Parse & Import CSV Products
                  </button>
                </div>

                {/* Stock Expiring Date Batches Log */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 text-slate-300 uppercase">
                    Expirations & Batch Entry
                  </h3>
                  <form onSubmit={handleAddBatch} className="space-y-3 text-xs">
                    <div className="space-y-1">
                      <label>Select Product</label>
                      <select
                        value={newBatch.product_id}
                        onChange={(e) => setNewBatch(prev => ({ ...prev, product_id: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg"
                      >
                        <option value="">-- Choose target product --</option>
                        {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label>Batch Code</label>
                        <input
                          type="text"
                          required
                          value={newBatch.batch_number}
                          onChange={(e) => setNewBatch(prev => ({ ...prev, batch_number: e.target.value }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-lg font-mono"
                          placeholder="SL-B09"
                        />
                      </div>
                      <div className="space-y-1">
                        <label>Expiry Date</label>
                        <input
                          type="date"
                          required
                          value={newBatch.expiry_date}
                          onChange={(e) => setNewBatch(prev => ({ ...prev, expiry_date: e.target.value }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-lg"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label>Qty Intake</label>
                        <input
                          type="number"
                          required
                          value={newBatch.quantity_received || ""}
                          onChange={(e) => setNewBatch(prev => ({ ...prev, quantity_received: parseInt(e.target.value || "0") }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-lg"
                        />
                      </div>
                      <div className="space-y-1">
                        <label>Manufacture Date</label>
                        <input
                          type="date"
                          value={newBatch.manufacturing_date}
                          onChange={(e) => setNewBatch(prev => ({ ...prev, manufacturing_date: e.target.value }))}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-lg"
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-lg transition"
                    >
                      Receive Expiry Batch
                    </button>
                  </form>
                </div>
              </div>

              {/* Master Database Table with red-zoned low stock indicators */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="p-4 bg-slate-850 border-b border-slate-800 flex justify-between items-center">
                  <h3 className="text-sm font-bold uppercase text-slate-300">Live Shell Stock Catalog ({products.length} items)</h3>
                  <div className="flex gap-2">
                    <span className="text-xs bg-rose-500/10 text-rose-400 font-bold px-2.5 py-1 rounded-full border border-rose-500/20">
                      Red highlight = Low Stock Alerts
                    </span>
                  </div>
                </div>

                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-500 text-[11px] font-semibold uppercase border-b border-slate-800">
                      <th className="p-3 pl-6">Product Item</th>
                      <th className="p-3 text-center">Barcode SKU</th>
                      <th className="p-3 text-right">Buying price</th>
                      <th className="p-3 text-right">Selling Price</th>
                      <th className="p-3 text-center">Shell Stock Level</th>
                      <th className="p-3 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 text-xs">
                    {products.map((prod) => {
                      const isLowStock = prod.stock_level <= prod.min_stock_level;
                      return (
                        <tr key={prod.id} className={`hover:bg-slate-850/30 transition ${isLowStock ? "bg-rose-500/5" : ""}`}>
                          <td className="p-3 pl-6">
                            <div className="font-bold text-slate-200">{prod.name}</div>
                            <div className="text-[10px] text-slate-500">{prod.category_name}</div>
                          </td>
                          <td className="p-3 text-center font-mono text-slate-400 text-[11px]">
                            {prod.barcode} • {prod.sku_code}
                          </td>
                          <td className="p-3 text-right font-mono text-slate-400">
                            KSh {prod.buying_price}
                          </td>
                          <td className="p-3 text-right font-mono font-semibold text-slate-200">
                            KSh {prod.selling_price}
                          </td>
                          <td className="p-3 text-center">
                            <span className={`px-2.5 py-1 rounded-full font-mono font-black ${
                              isLowStock 
                                ? "bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] animate-pulse" 
                                : "bg-slate-950 text-emerald-400 border border-slate-800 text-[11px]"
                            }`}>
                              {prod.stock_level} units
                            </span>
                          </td>
                          <td className="p-3 text-center flex justify-center gap-1">
                            {isLowStock && (
                              <button
                                onClick={() => handleAutoPO(prod)}
                                className="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded text-[10px]"
                              >
                                Auto PO
                              </button>
                            )}
                            <button
                              onClick={() => setEditProduct(prod)}
                              className="text-slate-400 hover:text-orange-400 p-1.5 rounded transition"
                              title="Edit Product Details"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(prod.id)}
                              className="text-slate-500 hover:text-rose-400 p-1.5 rounded"
                            >
                              <Trash className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: SELLERS & STAFF MANAGEMENT */}
          {activeTab === "sellers" && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Seller Form */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 text-slate-300 uppercase">
                    {editingSellerId ? "Edit Seller Cashier" : "Register New Seller"}
                  </h3>
                  <form onSubmit={handleCreateOrUpdateSeller} className="space-y-4 text-xs">
                    <div className="space-y-1">
                      <label className="text-slate-400 font-semibold">Cashier Full Name</label>
                      <input
                        type="text"
                        required
                        value={newSellerForm.name}
                        onChange={(e) => setNewSellerForm(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg text-white"
                        placeholder="e.g. Mercy Wanjiku"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-semibold">Secret 4-Digit PIN</label>
                      <input
                        type="password"
                        maxLength={4}
                        required
                        value={newSellerForm.pin_code}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, "");
                          setNewSellerForm(prev => ({ ...prev, pin_code: val }));
                        }}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg text-white font-mono tracking-widest text-lg text-center"
                        placeholder="••••"
                      />
                      <p className="text-[10px] text-slate-500">Only numeric values allowed. Will be used by the seller to login.</p>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-semibold">System Authorization Role</label>
                      <select
                        value={newSellerForm.role}
                        onChange={(e) => setNewSellerForm(prev => ({ ...prev, role: e.target.value as any }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg text-white"
                      >
                        <option value="Seller">Seller (Cashier / Sales Terminal only)</option>
                        <option value="Admin">Admin (Full Control Room access)</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-semibold">Employment Status</label>
                      <select
                        value={newSellerForm.status}
                        onChange={(e) => setNewSellerForm(prev => ({ ...prev, status: e.target.value as any }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg text-white"
                      >
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive (Suspended)</option>
                      </select>
                    </div>

                    <div className="flex gap-2 pt-2">
                      {editingSellerId && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingSellerId(null);
                            setNewSellerForm({ name: "", pin_code: "", status: "Active", role: "Seller" });
                          }}
                          className="flex-1 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold rounded-lg transition"
                        >
                          Cancel
                        </button>
                      )}
                      <button
                        type="submit"
                        className="flex-1 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-lg transition"
                      >
                        {editingSellerId ? "Save Seller" : "Register Seller"}
                      </button>
                    </div>
                  </form>
                </div>

                {/* Seller Matrix List */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden col-span-2">
                  <div className="p-4 bg-slate-850 border-b border-slate-800 flex justify-between items-center">
                    <h3 className="text-sm font-bold uppercase text-slate-300">Authorized Cashiers & Staff ({usersList.length})</h3>
                    <button 
                      onClick={fetchUsersList}
                      className="px-2.5 py-1 bg-slate-950 border border-slate-800 text-[10px] text-slate-400 hover:text-white rounded transition"
                    >
                      Refresh Staff
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-950 text-slate-500 text-[10px] font-semibold uppercase border-b border-slate-800">
                          <th className="p-3 pl-6">Cashier Name</th>
                          <th className="p-3 text-center">Assigned Role</th>
                          <th className="p-3 text-center">Auth PIN</th>
                          <th className="p-3 text-center">Terminal Status</th>
                          <th className="p-3 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850 text-xs">
                        {isSellersLoading ? (
                          <tr>
                            <td colSpan={5} className="p-12 text-center text-slate-500 font-semibold font-mono">
                              Loading staff members list...
                            </td>
                          </tr>
                        ) : usersList.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="p-12 text-center text-slate-500 font-semibold font-mono">
                              No staff members registered.
                            </td>
                          </tr>
                        ) : (
                          usersList.map((user) => (
                            <tr key={user.id} className="hover:bg-slate-850/30 transition">
                              <td className="p-3 pl-6">
                                <div className="font-bold text-slate-200">{user.name}</div>
                                <div className="text-[10px] text-slate-500">ID: {user.id}</div>
                              </td>
                              <td className="p-3 text-center">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  user.role === "Admin" 
                                    ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" 
                                    : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                                }`}>
                                  {user.role}
                                </span>
                              </td>
                              <td className="p-3 text-center font-mono font-bold text-slate-300">
                                <span className="bg-slate-950 px-2 py-1 rounded border border-slate-850 tracking-wider">
                                  {user.pin_code}
                                </span>
                              </td>
                              <td className="p-3 text-center">
                                <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                                  user.status === "Active" 
                                    ? "bg-green-500/10 text-green-400 border border-green-500/20" 
                                    : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                }`}>
                                  {user.status}
                                </span>
                              </td>
                              <td className="p-3 text-center">
                                <div className="flex justify-center items-center gap-1.5">
                                  <button
                                    onClick={() => {
                                      setEditingSellerId(user.id);
                                      setNewSellerForm({ 
                                        name: user.name, 
                                        pin_code: user.pin_code, 
                                        status: user.status as any,
                                        role: (user.role || "Seller") as any
                                      });
                                    }}
                                    className="p-1.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded transition cursor-pointer"
                                    title="Edit Cashier Profile"
                                  >
                                    <Edit className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteSeller(user.id)}
                                    className="p-1.5 bg-slate-800 hover:bg-slate-750 text-rose-500 rounded transition cursor-pointer"
                                    title="Delete Cashier Profile"
                                  >
                                    <Trash className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: RECEIPTS & LOGS */}
          {activeTab === "receipts" && (
            <div className="space-y-6 animate-fade-in">
              <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-500/15 text-orange-500 rounded-lg animate-pulse">
                      <Printer className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold uppercase text-slate-300 font-mono">Live Transaction & Receipt Ledger</h3>
                      <p className="text-[10px] text-slate-500 font-mono">Inspect, audit, print, and download eTIMS compliant thermal slips</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 items-center">
                    {/* Receipt Date Filter */}
                    <div className="flex gap-1 bg-slate-950 p-1 rounded-md border border-slate-850 text-[11px] font-mono">
                      <button
                        onClick={() => setReceiptDateFilter("all")}
                        className={`px-3 py-1 font-bold rounded transition cursor-pointer ${receiptDateFilter === "all" ? "bg-slate-800 text-white" : "text-slate-400 hover:text-slate-200"}`}
                      >
                        All History
                      </button>
                      <button
                        onClick={() => setReceiptDateFilter("today")}
                        className={`px-3 py-1 font-bold rounded transition cursor-pointer ${receiptDateFilter === "today" ? "bg-slate-800 text-white" : "text-slate-400 hover:text-slate-200"}`}
                      >
                        Today
                      </button>
                    </div>

                    {/* Search Field */}
                    <div className="relative font-mono">
                      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 w-3.5 h-3.5" />
                      <input
                        type="text"
                        placeholder="Search receipt no., cashier, B2B PIN..."
                        value={searchReceiptQuery}
                        onChange={(e) => setSearchReceiptQuery(e.target.value)}
                        className="bg-slate-950 border border-slate-800 text-xs text-white rounded-md pl-8 pr-4 py-1.5 w-64 focus:outline-none focus:border-orange-500 font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* High Density Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-950 text-slate-500 text-[10px] font-semibold uppercase border-b border-slate-800">
                        <th className="p-3 pl-4">Timestamp</th>
                        <th className="p-3">Receipt No</th>
                        <th className="p-3">Cashier</th>
                        <th className="p-3">Payment Method</th>
                        <th className="p-3 text-right">Items Count</th>
                        <th className="p-3 text-right font-mono">Grand Total Due</th>
                        <th className="p-3 text-center">eTIMS Sync</th>
                        <th className="p-3 text-center font-mono">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850 text-xs">
                      {(() => {
                        const filtered = transactions.filter(tx => {
                          // Date filter
                          if (receiptDateFilter === "today") {
                            const txDate = new Date(tx.timestamp).toDateString();
                            const today = new Date().toDateString();
                            if (txDate !== today) return false;
                          }

                          // Search query
                          if (searchReceiptQuery.trim()) {
                            const query = searchReceiptQuery.toLowerCase();
                            const receiptNum = (tx.receipt_number || tx.id || "").toLowerCase();
                            const cashierName = (tx.cashier_name || "").toLowerCase();
                            const payMethod = (tx.payment_method || "").toLowerCase();
                            const b2bPin = (tx.buyer_kra_pin || "").toLowerCase();
                            const grandTotal = tx.grand_total.toString();
                            
                            return (
                              receiptNum.includes(query) ||
                              cashierName.includes(query) ||
                              payMethod.includes(query) ||
                              b2bPin.includes(query) ||
                              grandTotal.includes(query)
                            );
                          }

                          return true;
                        });

                        if (filtered.length === 0) {
                          return (
                            <tr>
                              <td colSpan={8} className="p-12 text-center text-slate-500 font-semibold font-mono">
                                No receipts logged in the database yet.
                              </td>
                            </tr>
                          );
                        }

                        // Sorted by newest first
                        const sorted = [...filtered].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

                        return sorted.map((tx) => {
                          const itemsCount = tx.lines.reduce((acc, l) => acc + l.quantity, 0);
                          return (
                            <tr key={tx.id} className="hover:bg-slate-850/40 transition">
                              <td className="p-3 pl-4 text-slate-400 font-mono text-[11px]">
                                {new Date(tx.timestamp).toLocaleString()}
                              </td>
                              <td className="p-3 font-mono font-bold text-orange-400 text-xs">
                                {tx.receipt_number || tx.id}
                              </td>
                              <td className="p-3 text-slate-300 font-semibold">
                                {tx.cashier_name}
                              </td>
                              <td className="p-3 font-mono">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  tx.payment_method === "M-Pesa" 
                                    ? "bg-blue-500/10 text-blue-400 border border-blue-500/20" 
                                    : tx.payment_method === "Cash" 
                                    ? "bg-green-500/10 text-green-400 border border-green-500/20" 
                                    : "bg-purple-500/10 text-purple-400 border border-purple-500/20"
                                }`}>
                                  {tx.payment_method}
                                </span>
                              </td>
                              <td className="p-3 text-right font-mono text-slate-300">
                                {itemsCount} items
                              </td>
                              <td className="p-3 text-right font-mono font-bold text-slate-200">
                                KSh {tx.grand_total.toLocaleString()}
                              </td>
                              <td className="p-3 text-center">
                                <span className="bg-green-500/10 text-green-400 font-bold px-2 py-0.5 rounded text-[9px] uppercase tracking-wider font-mono">
                                  SUCCESS SYNC
                                </span>
                              </td>
                              <td className="p-3 text-center">
                                <div className="flex justify-center items-center gap-1.5">
                                  <button
                                    onClick={() => setSelectedReceipt(tx)}
                                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded transition cursor-pointer"
                                    title="Inspect Thermal Slip"
                                  >
                                    <Eye className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => downloadReceiptTXT(tx)}
                                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-orange-500 rounded transition cursor-pointer"
                                    title="Download 80mm TXT Receipt"
                                  >
                                    <Download className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SUPPLIERS & PROCUREMENT */}
          {activeTab === "suppliers" && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-3 gap-6">
                {/* Supplier profiles */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4 col-span-1">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 uppercase text-slate-300">
                    Register wholesale Supplier
                  </h3>
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    fetch("/api/suppliers", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify(newSupplier)
                    }).then(r => r.json()).then(d => {
                      if (d.success) {
                        alert("Wholesale Supplier linked!");
                        setNewSupplier({ name: "", phone: "", email: "", address: "", balance_due: 0 });
                        onRefreshSuppliers();
                      }
                    });
                  }} className="space-y-3 text-xs">
                    <div className="space-y-1">
                      <label>Supplier Company Name</label>
                      <input
                        type="text"
                        required
                        value={newSupplier.name}
                        onChange={(e) => setNewSupplier(p => ({ ...p, name: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg"
                        placeholder="e.g. Brookside Dairy Nairobi"
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Contact Phone</label>
                      <input
                        type="text"
                        required
                        value={newSupplier.phone}
                        onChange={(e) => setNewSupplier(p => ({ ...p, phone: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono"
                        placeholder="07..."
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Email orders</label>
                      <input
                        type="email"
                        required
                        value={newSupplier.email}
                        onChange={(e) => setNewSupplier(p => ({ ...p, email: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono"
                        placeholder="orders@supplier.co.ke"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-lg transition"
                    >
                      Log wholesale supplier
                    </button>
                  </form>
                </div>

                {/* Dead Stock filtration report */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4 col-span-2">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 text-slate-300 uppercase">
                    Dead Stock Filter (Zero Sales Velocity Over 90 Days)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Calculates idle wholesale assets currently frozen on shelves without any consumer traction.
                  </p>
                  
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-950 text-slate-500 text-[10px] border-b border-slate-850 uppercase">
                        <th className="p-3 pl-4">Product Name</th>
                        <th className="p-3 text-center">Available Stock</th>
                        <th className="p-3 text-right">Buying Price</th>
                        <th className="p-3 text-right">Frozen Asset Value</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850">
                      {products.filter(p => p.stock_level > 20).slice(0, 3).map(p => (
                        <tr key={p.id} className="hover:bg-slate-850/20">
                          <td className="p-3 pl-4 font-bold">{p.name}</td>
                          <td className="p-3 text-center font-mono">{p.stock_level} units</td>
                          <td className="p-3 text-right font-mono">KSh {p.buying_price}</td>
                          <td className="p-3 text-right font-mono font-bold text-rose-400">
                            KSh {(p.buying_price * p.stock_level).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Outstanding Purchase Orders history log */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="p-4 bg-slate-850 border-b border-slate-800">
                  <h3 className="text-sm font-bold uppercase text-slate-300">Outgoing Purchase Orders Logs</h3>
                </div>
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950 text-slate-500 text-[10px] border-b border-slate-850 uppercase">
                      <th className="p-3 pl-6">PO Number</th>
                      <th className="p-3">Supplier Name</th>
                      <th className="p-3 text-center">Issue Date</th>
                      <th className="p-3 text-right">Grand Total Cost</th>
                      <th className="p-3 text-center">Tracking Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850">
                    {purchaseOrders.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-500 font-semibold">
                          No outstanding POs registered. Utilize Auto PO.
                        </td>
                      </tr>
                    ) : (
                      purchaseOrders.map((po) => (
                        <tr key={po.id} className="hover:bg-slate-850/20">
                          <td className="p-3 pl-6 font-mono font-bold text-emerald-400">{po.id}</td>
                          <td className="p-3">{po.supplier_name}</td>
                          <td className="p-3 text-center font-mono">{po.date}</td>
                          <td className="p-3 text-right font-mono font-bold text-slate-200">
                            KSh {po.total_amount.toLocaleString()}
                          </td>
                          <td className="p-3 text-center">
                            <span className="bg-cyan-500/10 text-cyan-400 font-bold px-2 py-0.5 rounded text-[10px]">
                              {po.status}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: ANTI-THEFT AUDITING & SECURITY */}
          {activeTab === "security" && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-3 gap-6">
                {/* Suspicious Activities heatmap alerts */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl col-span-2 space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 uppercase text-rose-400 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-400 animate-pulse" />
                    <span>Suspicious Cashier Activity alerts</span>
                  </h3>
                  <div className="space-y-3">
                    {auditVoids.length === 0 ? (
                      <div className="text-center py-12 text-slate-500 text-xs font-semibold">
                        No high-risk security interventions detected so far today.
                      </div>
                    ) : (
                      auditVoids.map((log) => (
                        <div key={log.id} className="bg-slate-950 p-4 border border-rose-500/10 rounded-xl space-y-2">
                          <div className="flex justify-between items-center text-xs">
                            <span className="bg-rose-500/10 text-rose-400 font-bold px-2 py-0.5 rounded text-[10px]">
                              {log.action_taken}
                            </span>
                            <span className="text-slate-500 font-mono">{new Date(log.timestamp).toLocaleTimeString()}</span>
                          </div>
                          <div className="text-xs font-bold text-slate-200">
                            Cashier {log.cashier_name} triggered: <span className="text-slate-400 font-normal">{log.item_removed_name}</span>
                          </div>
                          <div className="text-[11px] text-slate-500 italic bg-slate-900/50 p-2 rounded">
                            Reason: {log.reason}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Manager Overrides & PIN rules configurations */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 uppercase text-slate-300">
                    Manager Overrides matrix
                  </h3>
                  <p className="text-xs text-slate-400">
                    Toggle strict guardrails forcing the cashier to request Manager PIN on-the-spot.
                  </p>
                  <div className="space-y-3.5 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-slate-950 rounded transition">
                      <input type="checkbox" defaultChecked className="accent-emerald-500 w-4 h-4 rounded" />
                      <span>Voiding a scanned item</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-slate-950 rounded transition">
                      <input type="checkbox" defaultChecked className="accent-emerald-500 w-4 h-4 rounded" />
                      <span>Wiping / clearing a full cart</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-slate-950 rounded transition">
                      <input type="checkbox" defaultChecked className="accent-emerald-500 w-4 h-4 rounded" />
                      <span>Manually entering product prices</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-slate-950 rounded transition">
                      <input type="checkbox" defaultChecked className="accent-emerald-500 w-4 h-4 rounded" />
                      <span>Discounts exceeding 5% thresholds</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: LEDGER & SAFE CASH DROPS */}
          {activeTab === "ledger" && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-2 gap-6">
                {/* Petty Cash drawer disbursements */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 uppercase text-slate-300">
                    Petty Cash Drawer Expenses
                  </h3>
                  <div className="space-y-3.5">
                    {pettyCash.length === 0 ? (
                      <div className="text-center py-12 text-slate-500 text-xs font-semibold">
                        No petty cash drawer payments logged today.
                      </div>
                    ) : (
                      pettyCash.map((item) => (
                        <div key={item.id} className="flex justify-between items-center bg-slate-950 p-3 rounded-xl border border-slate-850">
                          <div>
                            <div className="text-xs font-bold text-slate-200">{item.reason}</div>
                            <div className="text-[10px] text-slate-500">Paid by Cashier: {item.cashier_name}</div>
                          </div>
                          <span className="text-xs font-mono font-bold text-rose-400">
                            - KSh {item.amount}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Vault Safe Drops history */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 uppercase text-slate-300">
                    Safe Deposits (Vault Drops)
                  </h3>
                  <div className="space-y-3.5">
                    {safeDrops.length === 0 ? (
                      <div className="text-center py-12 text-slate-500 text-xs font-semibold">
                        No drawer-to-safe deposits recorded mid-shift.
                      </div>
                    ) : (
                      safeDrops.map((drop) => (
                        <div key={drop.id} className="flex justify-between items-center bg-slate-950 p-3 rounded-xl border border-slate-850">
                          <div>
                            <div className="text-xs font-bold text-slate-200">Safe Vault Drop</div>
                            <div className="text-[10px] text-slate-500">
                              Verified by: {drop.manager_name} • Cashier: {drop.cashier_name}
                            </div>
                          </div>
                          <span className="text-xs font-mono font-bold text-emerald-400">
                            KSh {drop.amount}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: SETTINGS & GATEWAYS */}
          {activeTab === "settings" && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-2 gap-6">
                {/* Receipt template customizer */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 uppercase text-slate-300">
                    80mm receipt thermal customizer
                  </h3>
                  <div className="space-y-3 text-xs">
                    <div className="space-y-1">
                      <label>Header Logo Text</label>
                      <input
                        type="text"
                        value={receiptSettings.logoText}
                        onChange={(e) => setReceiptSettings(p => ({ ...p, logoText: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label>Business KRA PIN</label>
                        <input
                          type="text"
                          value={receiptSettings.kraPin}
                          onChange={(e) => setReceiptSettings(p => ({ ...p, kraPin: e.target.value }))}
                          className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label>Shop Contact Phone</label>
                        <input
                          type="text"
                          value={receiptSettings.phone}
                          onChange={(e) => setReceiptSettings(p => ({ ...p, phone: e.target.value }))}
                          className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono"
                        />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label>Physical Shop Address</label>
                      <input
                        type="text"
                        value={receiptSettings.address}
                        onChange={(e) => setReceiptSettings(p => ({ ...p, address: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg"
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Footer Policy Custom Note</label>
                      <textarea
                        rows={3}
                        value={receiptSettings.footerText}
                        onChange={(e) => setReceiptSettings(p => ({ ...p, footerText: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 p-2.5 rounded-lg text-xs"
                      />
                    </div>
                  </div>
                </div>

                {/* Safaricom Daraja M-Pesa API integration settings */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold border-b border-slate-800 pb-2 uppercase text-slate-300">
                    Safaricom Daraja API Webhooks config
                  </h3>
                  <div className="space-y-3.5 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Enable M-Pesa STK Gateway</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={mpesaSettings.isEnabled}
                          onChange={(e) => setMpesaSettings(p => ({ ...p, isEnabled: e.target.checked }))}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-slate-850 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                      </label>
                    </div>

                    <div className="space-y-1">
                      <label>Lipa Na M-Pesa Till / Paybill Shortcode</label>
                      <input
                        type="text"
                        value={mpesaSettings.tillNumber}
                        onChange={(e) => setMpesaSettings(p => ({ ...p, tillNumber: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono text-cyan-400"
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Consumer Key</label>
                      <input
                        type="password"
                        value={mpesaSettings.consumerKey}
                        onChange={(e) => setMpesaSettings(p => ({ ...p, consumerKey: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono text-xs"
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Consumer Secret</label>
                      <input
                        type="password"
                        value={mpesaSettings.consumerSecret}
                        onChange={(e) => setMpesaSettings(p => ({ ...p, consumerSecret: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg font-mono text-xs"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <button
                  onClick={saveSettings}
                  className="px-8 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-xl text-xs transition shadow-lg"
                >
                  Save Global Configuration Gateways
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* THERMAL SLIP DETAILS MODAL */}
      {selectedReceipt && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 overflow-y-auto animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 relative flex flex-col max-h-[90vh]">
            <h3 className="text-sm font-bold uppercase text-slate-300 font-mono mb-4 flex items-center gap-2">
              <Printer className="w-4 h-4 text-orange-500" />
              <span>Inspect Thermal Audit Receipt</span>
            </h3>

            {/* Jagged paper edge simulated container */}
            <div className="flex-1 overflow-y-auto bg-white text-slate-900 p-6 rounded-xl font-mono text-xs shadow-inner space-y-4 border border-slate-200">
              {/* Receipt Header */}
              <div className="text-center space-y-1">
                <div className="font-bold text-[14px] tracking-tight">{receiptSettings.logoText}</div>
                <div className="text-[11px] font-semibold">{receiptSettings.shopName || "Metro Smart Retail Ltd"}</div>
                <div>KRA PIN: {receiptSettings.kraPin}</div>
                <div>Address: {receiptSettings.address}</div>
                <div>Tel: {receiptSettings.phone}</div>
              </div>

              {/* Meta Data */}
              <div className="border-t border-dashed border-slate-400 pt-3 space-y-1">
                <div className="flex justify-between">
                  <span>DATE:</span>
                  <span>{new Date(selectedReceipt.timestamp).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>RECEIPT NO:</span>
                  <span className="font-bold">{selectedReceipt.receipt_number || selectedReceipt.id}</span>
                </div>
                <div className="flex justify-between">
                  <span>CASHIER:</span>
                  <span>{selectedReceipt.cashier_name.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span>SHIFT ID:</span>
                  <span>{selectedReceipt.shift_id.substring(0, 8)}</span>
                </div>
              </div>

              {/* Line items */}
              <div className="border-t border-dashed border-slate-400 pt-3 space-y-2">
                <div className="grid grid-cols-12 font-bold border-b border-slate-200 pb-1">
                  <span className="col-span-6">ITEM</span>
                  <span className="col-span-2 text-center">QTY</span>
                  <span className="col-span-4 text-right">TOTAL</span>
                </div>
                {selectedReceipt.lines.map((line, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-1 py-0.5">
                    <div className="col-span-6">
                      <div className="font-bold">{line.product_name}</div>
                      <div className="text-[10px] text-slate-500">KSh {line.unit_price_at_sale} ({line.tax_category === "A" ? "16%" : "Exempt"})</div>
                    </div>
                    <span className="col-span-2 text-center">{line.quantity}</span>
                    <span className="col-span-4 text-right font-bold">KSh {(line.quantity * line.unit_price_at_sale).toLocaleString()}</span>
                  </div>
                ))}
              </div>

              {/* Totals Summary */}
              <div className="border-t border-dashed border-slate-400 pt-3 space-y-1.5 text-right">
                <div className="flex justify-between">
                  <span>SUBTOTAL:</span>
                  <span>KSh {selectedReceipt.subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>TAX (16% VAT):</span>
                  <span>KSh {selectedReceipt.tax_amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold text-sm border-t border-dashed border-slate-300 pt-1">
                  <span>GRAND TOTAL:</span>
                  <span>KSh {selectedReceipt.grand_total.toLocaleString()}</span>
                </div>
              </div>

              {/* Payment Details */}
              <div className="border-t border-dashed border-slate-400 pt-3 space-y-1">
                <div className="flex justify-between">
                  <span>PAYMENT METHOD:</span>
                  <span className="font-bold">{selectedReceipt.payment_method.toUpperCase()}</span>
                </div>
                {selectedReceipt.payment_method === "Cash" && (
                  <>
                    <div className="flex justify-between">
                      <span>CASH PAID:</span>
                      <span>KSh {selectedReceipt.cash_paid.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between font-bold">
                      <span>CHANGE DUE:</span>
                      <span>KSh {selectedReceipt.change_due.toLocaleString()}</span>
                    </div>
                  </>
                )}
                {selectedReceipt.payment_method === "M-Pesa" && (
                  <div className="flex justify-between">
                    <span>M-PESA REF CODE:</span>
                    <span className="font-bold text-blue-700">{selectedReceipt.mpesa_code || "MPESA_PUSH_LIVE"}</span>
                  </div>
                )}
                {selectedReceipt.buyer_kra_pin && (
                  <div className="flex justify-between">
                    <span>BUYER KRA PIN:</span>
                    <span className="font-bold">{selectedReceipt.buyer_kra_pin}</span>
                  </div>
                )}
              </div>

              {/* e-TIMS signature & Compliance */}
              <div className="border-t border-dashed border-slate-400 pt-3 text-center space-y-2">
                <div className="text-[10px] font-bold tracking-wider uppercase">KRA e-TIMS TAX COMPLIANCE</div>
                <div className="bg-slate-100 p-2 rounded text-[10px] font-mono select-all">
                  {selectedReceipt.e_tims_signature || "ETIMS-SIG-PENDING-MTR"}
                </div>
                
                {/* Visual barcode indicator */}
                <div className="flex flex-col items-center justify-center py-2 space-y-1">
                  <div className="w-full h-8 bg-black flex items-center justify-center text-white text-[9px] font-bold select-none leading-none tracking-[4px] uppercase">
                    ||||| | ||||| ||| ||| ||| | |||
                  </div>
                  <span className="text-[9px] text-slate-500">eTIMS Registered Secure Transaction</span>
                </div>
              </div>

              {/* Custom Policy Footer */}
              <div className="border-t border-dashed border-slate-400 pt-3 text-center text-[10px] text-slate-600 uppercase leading-normal">
                {receiptSettings.footerText}
              </div>
            </div>

            {/* Modal Controls */}
            <div className="flex gap-2 mt-4">
              <button
                onClick={() => downloadReceiptTXT(selectedReceipt)}
                className="flex-1 py-2 bg-orange-500 hover:bg-orange-600 text-slate-950 font-bold rounded-lg text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download (TXT)</span>
              </button>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold rounded-lg text-xs transition cursor-pointer"
              >
                Close Audit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QUICK EDIT PRODUCT MODAL */}
      {editProduct && editingProductForm && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 overflow-y-auto animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 relative">
            <h3 className="text-sm font-bold uppercase text-slate-300 font-mono mb-4 flex items-center gap-2 border-b border-slate-850 pb-2">
              <Edit className="w-4 h-4 text-orange-500" />
              <span>Quick Edit: {editProduct.name}</span>
            </h3>

            <form onSubmit={handleUpdateProduct} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-semibold">Product Name</label>
                  <input
                    type="text"
                    required
                    value={editingProductForm.name}
                    onChange={(e) => setEditingProductForm(p => p ? { ...p, name: e.target.value } : null)}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg text-white"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-semibold">Barcode Identifier</label>
                  <input
                    type="text"
                    required
                    value={editingProductForm.barcode}
                    onChange={(e) => setEditingProductForm(p => p ? { ...p, barcode: e.target.value } : null)}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-semibold">SKU Code</label>
                  <input
                    type="text"
                    required
                    value={editingProductForm.sku_code}
                    onChange={(e) => setEditingProductForm(p => p ? { ...p, sku_code: e.target.value } : null)}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg text-white font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-semibold">Tax Category</label>
                  <select
                    value={editingProductForm.tax_category}
                    onChange={(e) => setEditingProductForm(p => p ? { ...p, tax_category: e.target.value as any } : null)}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-lg text-white"
                  >
                    <option value="A">Category A - 16% VAT Standard</option>
                    <option value="B">Category B - Tax Exempt</option>
                    <option value="C">Category C - Zero Rated</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-semibold">Buying Cost (COGS)</label>
                  <div className="relative">
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-semibold font-mono">KSh</span>
                    <input
                      type="number"
                      required
                      min={0}
                      value={editingProductForm.buying_price}
                      onChange={(e) => setEditingProductForm(p => p ? { ...p, buying_price: parseFloat(e.target.value) || 0 } : null)}
                      className="w-full bg-slate-950 border border-slate-800 pl-10 pr-3 py-2 rounded-lg text-white font-mono"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-semibold">Retail Price</label>
                  <div className="relative">
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-semibold font-mono">KSh</span>
                    <input
                      type="number"
                      required
                      min={0}
                      value={editingProductForm.selling_price}
                      onChange={(e) => setEditingProductForm(p => p ? { ...p, selling_price: parseFloat(e.target.value) || 0 } : null)}
                      className="w-full bg-slate-950 border border-slate-800 pl-10 pr-3 py-2 rounded-lg text-white font-mono"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-semibold">Wholesale Price</label>
                  <div className="relative">
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-semibold font-mono">KSh</span>
                    <input
                      type="number"
                      required
                      min={0}
                      value={editingProductForm.wholesale_price}
                      onChange={(e) => setEditingProductForm(p => p ? { ...p, wholesale_price: parseFloat(e.target.value) || 0 } : null)}
                      className="w-full bg-slate-950 border border-slate-800 pl-10 pr-3 py-2 rounded-lg text-white font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 bg-slate-950/40 p-4 border border-slate-850 rounded-xl">
                <div className="space-y-1.5">
                  <label className="text-orange-400 font-bold">Wholesale Threshold Qty</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={editingProductForm.wholesale_threshold}
                    onChange={(e) => setEditingProductForm(p => p ? { ...p, wholesale_threshold: parseInt(e.target.value) || 1 } : null)}
                    className="w-full bg-slate-950 border border-slate-850 px-3 py-2 rounded-lg text-white font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-emerald-400 font-bold">Available Stock Level</label>
                  <input
                    type="number"
                    required
                    value={editingProductForm.stock_level}
                    onChange={(e) => setEditingProductForm(p => p ? { ...p, stock_level: parseInt(e.target.value) || 0 } : null)}
                    className="w-full bg-slate-950 border border-slate-850 px-3 py-2 rounded-lg text-emerald-400 font-bold font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-semibold">Min Stock Warning Level</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={editingProductForm.min_stock_level}
                    onChange={(e) => setEditingProductForm(p => p ? { ...p, min_stock_level: parseInt(e.target.value) || 0 } : null)}
                    className="w-full bg-slate-950 border border-slate-850 px-3 py-2 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setEditProduct(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-orange-500 hover:bg-orange-600 text-slate-950 font-black rounded-lg transition cursor-pointer"
                >
                  Save Product Updates
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Live Integration Sidebar Drawer */}
      <LiveIntegrationSidebar 
        products={products}
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
      />
    </div>
  );
}
