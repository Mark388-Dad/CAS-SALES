import React, { useState, useEffect, useRef } from "react";
import { 
  FileSpreadsheet, ExternalLink, Copy, Check, RefreshCw, 
  User, LogIn, LogOut, Database, Smartphone, X, AlertCircle
} from "lucide-react";
import { googleSignIn, googleLogout, getAccessToken, initGoogleAuth } from "../utils/googleAuth";
import { createSpreadsheet, syncAllProductsToSheet } from "../utils/googleSheetsSync";
import { Product } from "../types";

interface LiveIntegrationSidebarProps {
  products: Product[];
  isOpen: boolean;
  onClose: () => void;
}

interface MpesaLog {
  id: string;
  checkout_request_id: string;
  phone: string;
  amount: number;
  status: "Pending" | "Success" | "Failed" | "Cancelled";
  mpesa_code?: string;
  timestamp: string;
  error_message?: string;
}

export default function LiveIntegrationSidebar({ products, isOpen, onClose }: LiveIntegrationSidebarProps) {
  const [googleUser, setGoogleUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [spreadsheetId, setSpreadsheetId] = useState<string>("");
  const [spreadsheetUrl, setSpreadsheetUrl] = useState<string>("");
  const [isCreatingSheet, setIsCreatingSheet] = useState(false);
  const [isSyncingProducts, setIsSyncingProducts] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [mpesaLogs, setMpesaLogs] = useState<MpesaLog[]>([]);
  const [logsSearch, setLogsSearch] = useState("");
  const [isRefreshingLogs, setIsRefreshingLogs] = useState(false);

  // Keep track of processed transaction codes to trigger auto-copy
  const processedCodesRef = useRef<Set<string>>(new Set());

  // Fetch Settings (spreadsheet ID) on mount
  useEffect(() => {
    fetchSettings();
    fetchMpesaLogs();

    // Polling for live M-Pesa payments
    const mpesaInterval = setInterval(() => {
      fetchMpesaLogs(true);
    }, 8000);

    // Initialize Google auth state listener
    const unsubscribe = initGoogleAuth(
      (user, token) => {
        setGoogleUser(user);
        setAccessToken(token);
      },
      () => {
        setGoogleUser(null);
        setAccessToken(null);
      }
    );

    return () => {
      clearInterval(mpesaInterval);
      unsubscribe();
    };
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await fetch("/api/settings");
      const data = await res.json();
      if (data.settings) {
        setSpreadsheetId(data.settings.googleSpreadsheetId || "");
        setSpreadsheetUrl(data.settings.googleSpreadsheetUrl || "");
      }
    } catch (err) {
      console.error("Error fetching integration settings:", err);
    }
  };

  const saveSpreadsheetSettings = async (id: string, url: string) => {
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          googleSpreadsheetId: id,
          googleSpreadsheetUrl: url
        })
      });
      const data = await res.json();
      if (data.success && data.settings) {
        setSpreadsheetId(data.settings.googleSpreadsheetId || "");
        setSpreadsheetUrl(data.settings.googleSpreadsheetUrl || "");
      }
    } catch (err) {
      console.error("Failed to save spreadsheet settings to backend:", err);
    }
  };

  const fetchMpesaLogs = async (isPoll = false) => {
    if (!isPoll) setIsRefreshingLogs(true);
    try {
      const res = await fetch("/api/mpesa/logs");
      const logs: MpesaLog[] = await res.json();
      
      // Sort logs descending by timestamp
      const sorted = logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setMpesaLogs(sorted);

      // Auto-read and auto-copy successful M-Pesa transaction codes
      sorted.forEach(log => {
        if (log.status === "Success" && log.mpesa_code) {
          if (!processedCodesRef.current.has(log.mpesa_code)) {
            processedCodesRef.current.add(log.mpesa_code);
            // Only auto-copy if the log is relatively fresh (less than 1 minute old)
            const logTime = new Date(log.timestamp).getTime();
            const now = Date.now();
            if (now - logTime < 60000) {
              navigator.clipboard.writeText(log.mpesa_code);
              setCopiedCode(log.mpesa_code);
              // Clear copy indication after 3 seconds
              setTimeout(() => setCopiedCode(null), 3000);
            }
          }
        }
      });
    } catch (err) {
      console.error("Failed to fetch M-Pesa logs:", err);
    } finally {
      if (!isPoll) setIsRefreshingLogs(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
        setAccessToken(res.accessToken);
        alert("Google Sheets authorized successfully!");
      }
    } catch (err) {
      alert("Google login failed. Please ensure popups are allowed.");
    }
  };

  const handleGoogleLogout = async () => {
    try {
      await googleLogout();
      setGoogleUser(null);
      setAccessToken(null);
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  const handleCreateLedgerSheet = async () => {
    const token = accessToken || getAccessToken();
    if (!token) {
      alert("Please authenticate with Google first.");
      return;
    }

    setIsCreatingSheet(true);
    try {
      const info = await createSpreadsheet(token);
      await saveSpreadsheetSettings(info.spreadsheetId, info.spreadsheetUrl);
      
      // Auto trigger initial products sync
      await syncAllProductsToSheet(token, info.spreadsheetId, products);
      alert("Live Google Sheet created and synchronized successfully!");
    } catch (err: any) {
      console.error(err);
      alert(`Failed to create Google Sheet: ${err.message || err}`);
    } finally {
      setIsCreatingSheet(false);
    }
  };

  const handleSyncProducts = async () => {
    const token = accessToken || getAccessToken();
    if (!token || !spreadsheetId) {
      alert("Please verify Google Authentication and Spreadsheet connection.");
      return;
    }

    setIsSyncingProducts(true);
    try {
      await syncAllProductsToSheet(token, spreadsheetId, products);
      alert("All products catalogs have been synced to the Google Sheet!");
    } catch (err) {
      console.error(err);
      alert("Failed to sync products catalog.");
    } finally {
      setIsSyncingProducts(false);
    }
  };

  const handleManualCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const filteredLogs = mpesaLogs.filter(l => 
    l.phone.includes(logsSearch) || 
    (l.mpesa_code && l.mpesa_code.toLowerCase().includes(logsSearch.toLowerCase())) ||
    l.checkout_request_id.includes(logsSearch)
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-80 bg-slate-900 border-l border-slate-700 shadow-2xl z-50 flex flex-col h-full font-mono text-xs text-slate-300">
      {/* Drawer Header */}
      <div className="p-4 border-b border-slate-700 bg-slate-950 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-orange-500 animate-pulse" />
          <span className="font-bold tracking-wider text-[11px] uppercase text-white">Live Integrations Panel</span>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded transition text-slate-400 hover:text-white cursor-pointer">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-5">
        {/* GOOGLE SHEETS SYNC BLOCK */}
        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl space-y-3">
          <div className="flex justify-between items-center border-b border-slate-850 pb-2">
            <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Google Sheets Sync</span>
            </h3>
            {googleUser ? (
              <span className="text-[9px] px-1.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded font-black">
                ACTIVE
              </span>
            ) : (
              <span className="text-[9px] px-1.5 py-0.5 bg-slate-800 text-slate-500 rounded">
                OFFLINE
              </span>
            )}
          </div>

          {/* Connection controls */}
          {!googleUser ? (
            <div className="space-y-2">
              <p className="text-[10px] text-slate-500 leading-normal">
                Authorize Google to sync products catalog, payments, and checkout ledger records live.
              </p>
              <button
                onClick={handleGoogleLogin}
                className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Connect Google Account</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between bg-slate-900/60 p-2 border border-slate-850 rounded-lg">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-slate-800 rounded-full flex items-center justify-center text-[10px] font-bold text-white border border-slate-700">
                    {googleUser.email ? googleUser.email[0].toUpperCase() : "G"}
                  </div>
                  <div className="truncate max-w-[140px]">
                    <div className="text-white font-bold truncate text-[10px]">{googleUser.displayName || "Google User"}</div>
                    <div className="text-slate-500 text-[9px] truncate">{googleUser.email}</div>
                  </div>
                </div>
                <button
                  onClick={handleGoogleLogout}
                  title="Disconnect Google"
                  className="p-1 text-rose-400 hover:bg-rose-500/10 rounded transition cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Spreadsheet configuration details */}
              {spreadsheetId ? (
                <div className="space-y-2">
                  <div className="space-y-1.5">
                    <div className="text-[9px] text-slate-500 uppercase font-bold">Ledger Target Spreadsheet</div>
                    <a
                      href={spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-200 font-bold rounded-lg transition flex items-center justify-center gap-1.5 text-[10px]"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Open Live Sheet</span>
                    </a>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5 pt-1 text-[9px]">
                    <a
                      href={`${spreadsheetUrl}#gid=0`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 bg-slate-900 border border-slate-850 rounded hover:bg-slate-850 text-slate-400 hover:text-white flex items-center justify-between"
                    >
                      <span>Products Tab</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                    <a
                      href={`${spreadsheetUrl}#gid=1`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 bg-slate-900 border border-slate-850 rounded hover:bg-slate-850 text-slate-400 hover:text-white flex items-center justify-between"
                    >
                      <span>Ledger Tab</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={handleSyncProducts}
                      disabled={isSyncingProducts}
                      className="w-full py-1.5 bg-slate-800 hover:bg-slate-750 disabled:opacity-50 text-slate-300 font-bold rounded-lg border border-slate-750 transition flex items-center justify-center gap-1 text-[10px] cursor-pointer"
                    >
                      <RefreshCw className={`w-3 h-3 ${isSyncingProducts ? "animate-spin text-emerald-400" : ""}`} />
                      <span>{isSyncingProducts ? "Syncing Catalog..." : "Force Sync Products"}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2 bg-slate-900/40 p-2.5 border border-slate-850 rounded-lg">
                  <div className="flex gap-2 text-amber-400 text-[10px] items-start leading-normal">
                    <AlertCircle className="w-4 h-4 shrink-0 text-amber-500" />
                    <span>No ledger sheet target linked to this POS system.</span>
                  </div>
                  <button
                    onClick={handleCreateLedgerSheet}
                    disabled={isCreatingSheet}
                    className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-bold rounded-lg transition flex items-center justify-center gap-1 cursor-pointer"
                  >
                    {isCreatingSheet ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                    )}
                    <span>{isCreatingSheet ? "Provisioning Sheet..." : "Create New Google Sheet"}</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* SAFARICOM M-PESA REAL-TIME CODES FEED */}
        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl space-y-3 flex-1 flex flex-col min-h-[300px]">
          <div className="flex justify-between items-center border-b border-slate-850 pb-2">
            <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-teal-400" />
              <span>M-Pesa Live Ledger</span>
            </h3>
            <button
              onClick={() => fetchMpesaLogs()}
              disabled={isRefreshingLogs}
              title="Refresh ledger feed"
              className="p-1 hover:bg-slate-850 rounded transition text-slate-400 hover:text-white cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingLogs ? "animate-spin" : ""}`} />
            </button>
          </div>

          <input
            type="text"
            placeholder="Search by phone/code..."
            value={logsSearch}
            onChange={(e) => setLogsSearch(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-300 placeholder-slate-600 font-semibold font-mono"
          />

          <div className="space-y-2 overflow-y-auto flex-1 pr-0.5 max-h-[350px]">
            {filteredLogs.length === 0 ? (
              <div className="text-center py-8 text-slate-600">
                No transactions recorded
              </div>
            ) : (
              filteredLogs.map((log) => (
                <div 
                  key={log.id} 
                  className={`p-2.5 border rounded-lg space-y-1.5 transition-all bg-slate-900/40 ${
                    log.status === "Success" 
                      ? "border-emerald-950/40 hover:border-emerald-800/40" 
                      : log.status === "Pending" 
                        ? "border-amber-950/40 hover:border-amber-800/40" 
                        : "border-rose-950/40 hover:border-rose-800/40"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white text-[10px]">{log.phone}</span>
                    <span className="font-black text-white">KSh {log.amount}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-1.5">
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        log.status === "Success" 
                          ? "bg-green-500 animate-pulse" 
                          : log.status === "Pending" 
                            ? "bg-amber-500 animate-pulse" 
                            : "bg-red-500"
                      }`} />
                      <span className={`text-[9px] font-black ${
                        log.status === "Success" 
                          ? "text-green-400" 
                          : log.status === "Pending" 
                            ? "text-amber-400" 
                            : "text-red-400"
                      }`}>
                        {log.status.toUpperCase()}
                      </span>
                    </div>
                    <span className="text-[8px] text-slate-500">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>

                  {log.status === "Success" && log.mpesa_code && (
                    <div className="flex justify-between items-center bg-slate-950/60 p-1.5 rounded border border-slate-850 mt-1">
                      <span className="font-bold text-teal-400 font-mono tracking-wider">{log.mpesa_code}</span>
                      <button
                        onClick={() => handleManualCopy(log.mpesa_code!)}
                        className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition cursor-pointer"
                        title="Copy code to clipboard"
                      >
                        {copiedCode === log.mpesa_code ? (
                          <Check className="w-3.5 h-3.5 text-green-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  )}

                  {log.error_message && (
                    <div className="text-[9px] text-rose-400 italic font-medium leading-tight">
                      {log.error_message}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
